const sampleInput = `upper=0.23
lower=0.10

external:
A=2 B=5 C=1 D=3 E=6 F=4

batch DB0
T1: A:2 B:1 C:3
T2: C:1 D:2
T3: A:6 B:1 C:4 E:5
T4: A:4 B:4 E:3
T5: B:1 E:2 F:2

batch DB1
T6: A:3 F:3
T7: C:2 E:2

batch DB2
T8: B:5 C:1 D:3 E:2
T9: A:1 B:3 D:1`;

const inputEl = document.querySelector("#input");
const upperThresholdEl = document.querySelector("#upperThreshold");
const lowerThresholdEl = document.querySelector("#lowerThreshold");
const sampleFileEl = document.querySelector("#sampleFile");
const pipaSplitEl = document.querySelector("#pipaSplit");
const batchPreviewEl = document.querySelector("#batchPreview");
const syntheticRowsEl = document.querySelector("#syntheticRows");
const syntheticItemsEl = document.querySelector("#syntheticItems");
const syntheticWidthEl = document.querySelector("#syntheticWidth");
const syntheticBatchesEl = document.querySelector("#syntheticBatches");
const syntheticSeedEl = document.querySelector("#syntheticSeed");
const statusEl = document.querySelector("#status");
const metricsEl = document.querySelector("#metrics");
const runButtonEl = document.querySelector("#run");
const runPanelEl = document.querySelector("#runPanel");
const progressTextEl = document.querySelector("#progressText");
const progressPercentEl = document.querySelector("#progressPercent");
const progressFillEl = document.querySelector("#progressFill");
const stepListEl = document.querySelector("#stepList");
const insightGridEl = document.querySelector("#insightGrid");
const batchListEl = document.querySelector("#batchList");
const runtimeChartEl = document.querySelector("#runtimeChart");
const utilityChartEl = document.querySelector("#utilityChart");
const exportJsonBtn = document.querySelector("#exportJson");
const exportCsvBtn = document.querySelector("#exportCsv");
const exportPerformanceCsvBtn = document.querySelector("#exportPerformanceCsv");
const exportTxtBtn = document.querySelector("#exportTxt");
let lastReport = null;
let progressTimer = null;
let progressValue = 0;

inputEl.value = sampleInput;
syncThresholdInputsFromText();
renderInputPreview();

document.querySelector("#loadSample").addEventListener("click", () => {
  inputEl.value = sampleInput;
  syncThresholdInputsFromText();
  renderInputPreview();
  setStatus("Đã nạp mẫu");
});

runButtonEl.addEventListener("click", analyze);
document.querySelector("#refreshPreview").addEventListener("click", () => {
  syncThresholdInputsFromText();
  renderInputPreview();
  setStatus("Đã cập nhật cột dữ liệu");
});
inputEl.addEventListener("input", () => {
  renderInputPreview();
});
upperThresholdEl.addEventListener("input", () => setStatus("Đã thay đổi Su"));
lowerThresholdEl.addEventListener("input", () => setStatus("Đã thay đổi Sl"));
sampleFileEl.addEventListener("change", loadSampleFile);
document.querySelector("#generateSynthetic").addEventListener("click", generateSyntheticInput);
exportJsonBtn.addEventListener("click", () => download("bao-cao-pihaupa.json", JSON.stringify(lastReport, null, 2), "application/json"));
exportCsvBtn.addEventListener("click", () => download("patterns-pihaupa.csv", toCsv(lastReport), "text/csv"));
exportPerformanceCsvBtn.addEventListener("click", () => download("performance-by-rows.csv", toPerformanceCsv(lastReport), "text/csv"));
exportTxtBtn.addEventListener("click", () => download("bao-cao-pihaupa.txt", toText(lastReport), "text/plain"));

async function analyze() {
  const body = buildInputWithThresholds();
  if (!body) {
    return;
  }
  setStatus("Đang chạy...");
  setLoading(true);
  batchListEl.innerHTML = "";
  try {
    const response = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "text/plain; charset=utf-8" },
      body
    });
    const data = await response.json();
    if (!response.ok) {
      throw new Error(data.error || "Phân tích thất bại");
    }
    lastReport = data;
    renderReport(data);
    setStatus("Hoàn tất");
    finishLoading(true);
    setExportEnabled(true);
  } catch (error) {
    setStatus("Có lỗi");
    finishLoading(false);
    setExportEnabled(false);
    batchListEl.innerHTML = `<div class="error">${escapeHtml(error.message)}</div>`;
  }
}

function setLoading(isLoading) {
  runButtonEl.disabled = isLoading;
  runPanelEl.classList.toggle("is-running", isLoading);
  runPanelEl.classList.remove("has-error");
  if (!isLoading) {
    return;
  }
  progressValue = 8;
  updateProgress(progressValue, "Đang kiểm tra input và chuẩn hóa ngưỡng...");
  markStep(0);
  clearInterval(progressTimer);
  progressTimer = setInterval(() => {
    progressValue = Math.min(92, progressValue + Math.max(2, Math.round((96 - progressValue) / 7)));
    const stepIndex = progressValue < 22 ? 0
      : progressValue < 38 ? 1
      : progressValue < 55 ? 2
      : progressValue < 72 ? 3
      : progressValue < 86 ? 4
      : 5;
    const messages = [
      "Đang kiểm tra input và chuẩn hóa ngưỡng...",
      "Đang xây dựng PIHAUP-List từ các transaction...",
      "Đang sắp xếp AUUB và tính MRU/MRN...",
      "Đang mở rộng pattern, tính AU và MAU...",
      "Đang đánh giá tight re-scan cho batch mới...",
      "Đang tổng hợp thống kê hiển thị..."
    ];
    updateProgress(progressValue, messages[stepIndex]);
    markStep(stepIndex);
  }, 180);
}

function finishLoading(success) {
  clearInterval(progressTimer);
  progressTimer = null;
  runButtonEl.disabled = false;
  runPanelEl.classList.remove("is-running");
  if (success) {
    updateProgress(100, "Hoàn tất phân tích. Có thể xem thống kê hoặc xuất file.");
    markStep(5, true);
  } else {
    updateProgress(progressValue, "Dừng phân tích do input hoặc server có lỗi.");
    runPanelEl.classList.add("has-error");
  }
}

function updateProgress(percent, text) {
  progressFillEl.style.width = `${percent}%`;
  progressPercentEl.textContent = `${percent}%`;
  progressTextEl.textContent = text;
}

function markStep(activeIndex, completeAll = false) {
  [...stepListEl.children].forEach((item, index) => {
    item.classList.toggle("is-active", !completeAll && index === activeIndex);
    item.classList.toggle("is-done", completeAll || index < activeIndex);
  });
}

async function loadSampleFile() {
  const file = sampleFileEl.files?.[0];
  if (!file) {
    return;
  }
  try {
    const text = await file.text();
    const converted = maybeConvertPipaDataset(text, file.name);
    inputEl.value = converted.text;
    syncThresholdInputsFromText();
    renderInputPreview();
    setStatus(converted.converted ? `Đã chuyển file PIPA: ${file.name}` : `Đã tải file: ${file.name}`);
  } catch (error) {
    setStatus("Không đọc được file");
    batchListEl.innerHTML = `<div class="error">${escapeHtml(error.message)}</div>`;
  }
}

function maybeConvertPipaDataset(text, fileName) {
  const rawLines = text.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const dataLines = rawLines.filter(line => !line.startsWith("#"));
  const numericRows = dataLines
    .map(line => line.split(/\s+/))
    .filter(parts => parts.length >= 8 && parts.slice(0, 8).every(part => /^-?\d+(\.\d+)?$/.test(part)));

  if (numericRows.length < Math.max(5, Math.floor(dataLines.length * 0.8))) {
    return { converted: false, text };
  }

  const upper = upperThresholdEl.value || "0.23";
  const lower = lowerThresholdEl.value || "0.10";
  const transactions = new Map();
  const itemSet = new Set();

  for (const parts of numericRows) {
    const photoId = parts[1];
    const width = Math.max(1, Math.round(Number(parts[4])));
    const height = Math.max(1, Math.round(Number(parts[5])));
    const identity = `P${parts[6]}`;
    const utility = width * height;
    itemSet.add(identity);
    if (!transactions.has(photoId)) {
      transactions.set(photoId, new Map());
    }
    const items = transactions.get(photoId);
    items.set(identity, (items.get(identity) || 0) + utility);
  }

  const ratios = parseThreeRatios(pipaSplitEl.value);
  const transactionEntries = [...transactions.entries()];
  const splitCounts = allocateThreeCounts(transactionEntries.length, ratios);
  const batches = [];
  let offset = 0;
  for (let index = 0; index < 3; index++) {
    batches.push([`DB${index}`, transactionEntries.slice(offset, offset + splitCounts[index])]);
    offset += splitCounts[index];
  }

  const items = [...itemSet].sort(naturalCompare);
  const lines = [
    `# Tự chuyển đổi từ file PIPA: ${fileName}`,
    "# Quy ước: transaction = photo_id, item = identity_id, internal utility = width x height, external utility = 1.",
    `upper=${upper}`,
    `lower=${lower}`,
    "",
    "external:",
    items.map(item => `${item}=1`).join(" ")
  ];

  for (const [batchName, batchTransactions] of batches) {
    lines.push("", `batch ${batchName}`);
    for (const [photoId, itemUtilities] of batchTransactions) {
      const itemTokens = [...itemUtilities.entries()]
        .sort((a, b) => naturalCompare(a[0], b[0]))
        .map(([item, utility]) => `${item}:${utility}`);
      lines.push(`T${photoId}: ${itemTokens.join(" ")}`);
    }
  }

  return { converted: true, text: lines.join("\n") };
}

function parseThreeRatios(value) {
  const ratios = String(value).split(/[,;:]/).map(part => Number(part.trim()));
  if (ratios.length !== 3 || ratios.some(ratio => !Number.isFinite(ratio) || ratio <= 0)) {
    throw new Error("Tỷ lệ tách PIPA phải gồm đúng ba số dương, ví dụ 60,20,20.");
  }
  return ratios;
}

function allocateThreeCounts(total, ratios) {
  const sum = ratios.reduce((value, ratio) => value + ratio, 0);
  const exact = ratios.map(ratio => total * ratio / sum);
  const counts = exact.map(Math.floor);
  let remaining = total - counts.reduce((value, count) => value + count, 0);
  const order = [0, 1, 2].sort((a, b) => (exact[b] - counts[b]) - (exact[a] - counts[a]));
  for (let index = 0; index < remaining; index++) counts[order[index]]++;
  if (total >= 3) {
    for (let index = 0; index < 3; index++) {
      if (counts[index] === 0) {
        const donor = counts.indexOf(Math.max(...counts));
        counts[donor]--;
        counts[index]++;
      }
    }
  }
  return counts;
}

function generateSyntheticInput() {
  const rows = clampInt(syntheticRowsEl.value, 100, 1_000_000, 100_000);
  const itemCount = clampInt(syntheticItemsEl.value, 3, 200, 30);
  const width = clampInt(syntheticWidthEl.value, 1, Math.min(12, itemCount), 4);
  const batches = clampInt(syntheticBatchesEl.value, 1, Math.min(100, rows), 10);
  const seed = clampInt(syntheticSeedEl.value, 1, 2_147_483_647, 20_260_821);
  upperThresholdEl.value = "0.02";
  lowerThresholdEl.value = "0.01";
  const random = createRandom(seed);
  const external = [];
  for (let i = 1; i <= itemCount; i++) {
    external.push(`I${i}=${1 + Math.floor(random() * 9)}`);
  }

  const lines = [
    `# Synthetic dataset: ${rows} transaction, ${itemCount} item, ${width} item/giao dịch, ${batches} batch`,
    "# Sinh dữ liệu để benchmark PIHAUPA; item/giao dịch nhỏ giúp tránh nổ tổ hợp pattern.",
    `upper=${upperThresholdEl.value}`,
    `lower=${lowerThresholdEl.value}`,
    "",
    "external:",
    external.join(" ")
  ];

  let tid = 1;
  for (let batchIndex = 0; batchIndex < batches; batchIndex++) {
    const start = Math.floor((rows * batchIndex) / batches);
    const end = Math.floor((rows * (batchIndex + 1)) / batches);
    lines.push("", `batch DB${batchIndex}`);
    for (let row = start; row < end; row++) {
      const chosen = new Set();
      while (chosen.size < width) {
        chosen.add(1 + Math.floor(random() * itemCount));
      }
      const items = [...chosen]
        .sort((a, b) => a - b)
        .map(item => `I${item}:${1 + Math.floor(random() * 9)}`);
      lines.push(`T${tid++}: ${items.join(" ")}`);
    }
  }

  inputEl.value = lines.join("\n");
  renderInputPreview();
  setStatus(`Đã tạo ${rows.toLocaleString("vi-VN")} transaction`);
}

function clampInt(value, min, max, fallback) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) {
    return fallback;
  }
  return Math.min(max, Math.max(min, parsed));
}

function createRandom(seed) {
  let state = seed >>> 0;
  return () => {
    state = (1664525 * state + 1013904223) >>> 0;
    return state / 4294967296;
  };
}

function naturalCompare(a, b) {
  return String(a).localeCompare(String(b), "vi", { numeric: true, sensitivity: "base" });
}

function buildInputWithThresholds() {
  const upper = Number(upperThresholdEl.value);
  const lower = Number(lowerThresholdEl.value);
  if (!Number.isFinite(upper) || !Number.isFinite(lower) || lower <= 0 || upper <= 0 || lower >= upper) {
    setStatus("Ngưỡng chưa hợp lệ");
    batchListEl.innerHTML = `<div class="error">Vui lòng nhập ngưỡng hợp lệ: 0 &lt; Sl &lt; Su. Ví dụ trong bài báo: Su=0.23, Sl=0.10.</div>`;
    setExportEnabled(false);
    return null;
  }
  const text = inputEl.value;
  let next = replaceOrInsertLine(text, /^(upper|su)\s*=/i, `upper=${upper}`);
  next = replaceOrInsertLine(next, /^(lower|sl)\s*=/i, `lower=${lower}`);
  inputEl.value = next;
  renderInputPreview();
  return next;
}

function replaceOrInsertLine(text, pattern, replacement) {
  const lines = text.split(/\r?\n/);
  const index = lines.findIndex(line => pattern.test(line.trim()));
  if (index >= 0) {
    lines[index] = replacement;
    return lines.join("\n");
  }
  return `${replacement}\n${text}`;
}

function syncThresholdInputsFromText() {
  const upper = findThreshold(inputEl.value, /^(upper|su)\s*=\s*([0-9.]+)/i);
  const lower = findThreshold(inputEl.value, /^(lower|sl)\s*=\s*([0-9.]+)/i);
  if (upper !== null) {
    upperThresholdEl.value = upper;
  }
  if (lower !== null) {
    lowerThresholdEl.value = lower;
  }
}

function findThreshold(text, pattern) {
  for (const line of text.split(/\r?\n/)) {
    const match = line.trim().match(pattern);
    if (match) {
      return match[2];
    }
  }
  return null;
}

function renderInputPreview() {
  const parsed = parseInputText(inputEl.value);
  const totalTransactions = parsed.batches.reduce((sum, batch) => sum + batch.transactions.length, 0);
  const sizeMb = new Blob([inputEl.value]).size / (1024 * 1024);
  const external = parsed.external.length
    ? `<div class="external-preview"><strong>External utility:</strong><code>${escapeHtml(compactExternal(parsed.external.join(" ")))}</code></div>`
    : `<div class="external-preview muted">Chưa thấy dòng external utility.</div>`;
  const summary = `<div class="preview-summary">
    <strong>${parsed.batches.length.toLocaleString("vi-VN")} batch</strong>
    <strong>${totalTransactions.toLocaleString("vi-VN")} transaction</strong>
    <strong>${fmt(sizeMb)} MB input</strong>
    <span>Preview giới hạn 80 dòng đầu mỗi batch để chạy mượt với dữ liệu lớn.</span>
  </div>`;
  const batches = parsed.batches.length
    ? parsed.batches.map(renderBatchColumn).join("")
    : `<div class="preview-empty">Chưa có batch. Hãy thêm dòng dạng <code>batch DB0</code>.</div>`;
  batchPreviewEl.innerHTML = external + summary + `<div class="column-scroll">${batches}</div>`;
}

function compactExternal(text) {
  return text.length > 260 ? `${text.slice(0, 260)} ...` : text;
}

function parseInputText(text) {
  const external = [];
  const batches = [];
  let readingExternal = false;
  let current = null;

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.split("#")[0].trim();
    if (!line) {
      continue;
    }
    if (/^external:?$/i.test(line)) {
      readingExternal = true;
      continue;
    }
    if (/^batch\s+/i.test(line)) {
      current = { name: line.replace(/^batch\s+/i, "").trim(), transactions: [] };
      batches.push(current);
      readingExternal = false;
      continue;
    }
    if (/^(upper|lower|su|sl)\s*=/i.test(line)) {
      continue;
    }
    if (readingExternal) {
      external.push(line);
      continue;
    }
    if (current && line.includes(":")) {
      current.transactions.push(line);
    }
  }
  return { external, batches };
}

function renderBatchColumn(batch) {
  const previewLimit = 80;
  const shown = batch.transactions.slice(0, previewLimit);
  const rows = batch.transactions.length
    ? shown.map(transaction => `<li><code>${escapeHtml(transaction)}</code></li>`).join("")
    : `<li class="muted">Batch chưa có transaction.</li>`;
  const remaining = batch.transactions.length > previewLimit
    ? `<li class="muted">... còn ${Number(batch.transactions.length - previewLimit).toLocaleString("vi-VN")} giao dịch nữa</li>`
    : "";
  return `<article class="batch-column">
    <h3>${escapeHtml(batch.name)}</h3>
    <p>${batch.transactions.length} giao dịch</p>
    <ol>${rows}${remaining}</ol>
  </article>`;
}

function renderReport(report) {
  metricsEl.innerHTML = metric("Số batch", report.batchCount, "Số đợt dữ liệu được đưa vào lần lượt: DB0, DB1, DB2...")
    + metric("Số giao dịch", report.transactionCount, "Tổng số transaction trong toàn bộ input")
    + metric("Thời gian", `${fmt(report.elapsedMs)} ms`, "Tổng thời gian chạy thuật toán trên server Java")
    + metric("Heap đỉnh", `${fmt(report.peakMemoryMb)} MB`, "Mức heap Java cao nhất quan sát tại các mốc batch")
    + metric("Số lần quét lại", report.stats.rescanCount, "Số lần thỏa điều kiện tight re-scan và dựng lại cây pattern")
    + metric("Pattern đang quản lý", report.managedPatterns.length, "Số pattern LARGE/PRE-LARGE còn được giữ sau batch cuối");

  renderBars(runtimeChartEl, report.batches.map(batch => ({
    label: batch.name,
    value: batch.elapsedMs,
    text: `${fmt(batch.elapsedMs)} ms`
  })), false);

  renderBars(utilityChartEl, report.batches.flatMap(batch => ([
    { label: `${batch.name} TU`, value: batch.batchTransactionUtility, text: fmt(batch.batchTransactionUtility), alt: false },
    { label: `${batch.name} MU`, value: batch.batchMaximumUtility, text: fmt(batch.batchMaximumUtility), alt: true }
  ])), true);

  renderInsights(report);

  batchListEl.className = "batch-list";
  batchListEl.innerHTML = report.batches.map(renderBatch).join("");
}

function renderInsights(report) {
  const finalBatch = report.batches[report.batches.length - 1];
  const large = finalBatch ? finalBatch.largePatterns.length : 0;
  const preLarge = finalBatch ? finalBatch.preLargePatterns.length : 0;
  const total = Math.max(1, large + preLarge);
  const updateOnly = report.batches.filter(batch => batch.tightRescanLimit !== null && !batch.rescanTriggered).length;
  const incremental = Math.max(1, report.batches.length - 1);
  const updateRate = Math.round((updateOnly / incremental) * 100);
  const largeRate = Math.round((large / total) * 100);
  const preLargeRate = Math.round((preLarge / total) * 100);
  insightGridEl.innerHTML = `
    <div class="insight-card">
      <span>Tỷ lệ LARGE</span>
      <strong>${largeRate}%</strong>
      <div class="mini-meter"><i style="width:${largeRate}%"></i></div>
      <p>${large} mẫu đạt ngưỡng trên ở batch cuối</p>
    </div>
    <div class="insight-card">
      <span>Tỷ lệ PRE-LARGE</span>
      <strong>${preLargeRate}%</strong>
      <div class="mini-meter alt"><i style="width:${preLargeRate}%"></i></div>
      <p>${preLarge} mẫu tiềm năng được giữ lại</p>
    </div>
    <div class="insight-card">
      <span>Hiệu quả cập nhật</span>
      <strong>${updateRate}%</strong>
      <div class="mini-meter good"><i style="width:${updateRate}%"></i></div>
      <p>${updateOnly}/${incremental} batch insert không cần quét lại</p>
    </div>`;
}

function renderBatch(batch) {
  const badgeClass = batch.rescanTriggered ? "badge warn" : "badge";
  const decision = batch.tightRescanLimit === null
    ? "Quét khởi tạo"
    : `${batch.rescanTriggered ? "Quét lại" : "Cập nhật cây"} | MU=${fmt(batch.accumulatedMaximumUtility)} / giới hạn=${fmt(batch.tightRescanLimit)}`;
  return `<article class="batch-card">
    <div class="batch-summary">
      <div>
        <h2>${escapeHtml(batch.name)}</h2>
        <p>${escapeHtml(batch.action)}</p>
      </div>
      <div><span class="${badgeClass}">${decision}</span></div>
    </div>
    <div class="metrics">
      ${metric("Giao dịch", batch.transactionCount, "Số transaction trong batch này")}
      ${metric("TU batch", fmt(batch.batchTransactionUtility), "Tổng transaction utility của batch hiện tại")}
      ${metric("MU batch", fmt(batch.batchMaximumUtility), "Tổng maximum utility của batch hiện tại")}
      ${metric("Tổng TU", fmt(batch.totalTransactionUtility), "Tổng utility đã tích lũy đến hết batch này")}
      ${metric("minUtil trên", fmt(batch.minUtilUpper), "Ngưỡng LARGE = Su x Tổng TU")}
      ${metric("minUtil dưới", fmt(batch.minUtilLower), "Ngưỡng PRE-LARGE = Sl x Tổng TU")}
    </div>
    <div class="batch-note">
      <strong>Diễn giải:</strong> ${explainBatch(batch)}
    </div>
    <div class="pattern-grid">
      ${patternTable("HAUP / LARGE", batch.largePatterns, "Các mẫu có AU đạt ngưỡng trên, là kết quả chính.")}
      ${patternTable("PRE-LARGE", batch.preLargePatterns, "Các mẫu tiềm năng, được lưu để cập nhật nhanh khi batch mới đến.")}
    </div>
  </article>`;
}

function explainBatch(batch) {
  if (batch.tightRescanLimit === null) {
    return "Batch đầu tiên luôn quét dữ liệu và mở rộng pattern để tạo cây ban đầu.";
  }
  if (batch.rescanTriggered) {
    return "MU tích lũy của dữ liệu mới vượt giới hạn tight re-scan, nên chương trình quét lại toàn bộ dữ liệu đã tích lũy.";
  }
  return "MU tích lũy chưa vượt giới hạn tight re-scan, nên chương trình chỉ cập nhật utility trên cây pattern hiện có.";
}

function patternTable(title, patterns, note) {
  const rows = patterns.length
    ? patterns.map(pattern => `<tr>
        <td title="Danh sách item trong pattern">${escapeHtml(pattern.name)}</td>
        <td title="Lợi ích trung bình của pattern">${fmt(pattern.averageUtility)}</td>
        <td title="Tổng lợi ích của pattern">${fmt(pattern.sumUtility)}</td>
        <td title="Số item trong pattern">${pattern.length}</td>
      </tr>`).join("")
    : `<tr><td colspan="4">Không có pattern</td></tr>`;
  return `<div class="table-wrap">
    <h2>${title}</h2>
    <p class="table-note">${note}</p>
    <table>
      <thead><tr><th>Pattern</th><th>AU</th><th>sumU</th><th>Độ dài</th></tr></thead>
      <tbody>${rows}</tbody>
    </table>
  </div>`;
}

function renderBars(container, rows, allowAlt) {
  const max = Math.max(1, ...rows.map(row => row.value));
  container.innerHTML = rows.map(row => {
    const width = Math.max(3, (row.value / max) * 100);
    const cls = allowAlt && row.alt ? "fill alt" : "fill";
    return `<div class="bar-row">
      <span>${escapeHtml(row.label)}</span>
      <div class="track"><div class="${cls}" style="--w:${width}%"></div></div>
      <span>${escapeHtml(row.text)}</span>
    </div>`;
  }).join("");
}

function metric(label, value, note = "") {
  const title = note ? ` title="${escapeHtml(note)}"` : "";
  const extra = note ? `<small>${escapeHtml(note)}</small>` : "";
  return `<div${title}><span>${escapeHtml(String(label))}</span><strong>${escapeHtml(String(value))}</strong>${extra}</div>`;
}

function toCsv(report) {
  const rows = [["batch", "loai", "pattern", "items", "averageUtility_AU", "sumUtility_sumU", "doDai"]];
  for (const batch of report.batches) {
    for (const pattern of [...batch.largePatterns, ...batch.preLargePatterns]) {
      rows.push([batch.name, pattern.type, pattern.name, pattern.items, pattern.averageUtility, pattern.sumUtility, pattern.length]);
    }
  }
  return rows.map(row => row.map(csvCell).join(",")).join("\n");
}

function toPerformanceCsv(report) {
  const rows = [["batch", "batchRows", "cumulativeRows", "elapsedMs", "memoryBeforeMb", "memoryAfterMb", "peakMemoryMb", "batchTU", "batchMU", "totalTU", "rescanTriggered", "tightRescanDenominator", "tightRescanLimit", "originalRescanLimit", "largeCount", "preLargeCount"]];
  for (const batch of report.batches) {
    rows.push([batch.name, batch.transactionCount, batch.cumulativeTransactionCount, batch.elapsedMs,
      batch.memoryBeforeMb, batch.memoryAfterMb, batch.peakMemoryMb, batch.batchTransactionUtility,
      batch.batchMaximumUtility, batch.totalTransactionUtility, batch.rescanTriggered,
      batch.tightRescanDenominator ?? "", batch.tightRescanLimit ?? "", batch.originalRescanLimit ?? "",
      batch.largePatterns.length, batch.preLargePatterns.length]);
  }
  return rows.map(row => row.map(csvCell).join(",")).join("\n");
}

function toText(report) {
  const lines = [
    "BAO CAO PIHAUPA",
    `Su=${report.upperThreshold}, Sl=${report.lowerThreshold}`,
    `So batch=${report.batchCount}, So giao dich=${report.transactionCount}`,
    `Thoi gian=${fmt(report.elapsedMs)} ms, Bo nho tang=${fmt(report.memoryDeltaMb)} MB`,
    `So lan quet lai=${report.stats.rescanCount}, So pattern duyet=${report.stats.patternsVisited}, So node ket hop=${report.stats.combinedNodes}`,
    "",
    "CHU THICH:",
    "AU = Average Utility, loi ich trung binh cua pattern.",
    "TU = Transaction Utility, tong loi ich cua giao dich/tap giao dich.",
    "MU = Maximum Utility, tong loi ich lon nhat tung giao dich.",
    "LARGE/HAUP = pattern dat nguong tren.",
    "PRE-LARGE = pattern nam giua nguong duoi va nguong tren.",
    ""
  ];
  for (const batch of report.batches) {
    lines.push(`[${batch.name}] ${batch.action}`);
    lines.push(`TU=${fmt(batch.batchTransactionUtility)}, MU=${fmt(batch.batchMaximumUtility)}, TotalTU=${fmt(batch.totalTransactionUtility)}`);
    lines.push("HAUP/LARGE - pattern dat nguong tren:");
    for (const pattern of batch.largePatterns) {
      lines.push(`  ${pattern.name} AU=${fmt(pattern.averageUtility)} sumU=${fmt(pattern.sumUtility)} length=${pattern.length}`);
    }
    lines.push("PRE-LARGE - pattern tiem nang:");
    for (const pattern of batch.preLargePatterns) {
      lines.push(`  ${pattern.name} AU=${fmt(pattern.averageUtility)} sumU=${fmt(pattern.sumUtility)} length=${pattern.length}`);
    }
    lines.push("");
  }
  return lines.join("\n");
}

function download(filename, content, type) {
  if (!lastReport) return;
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function csvCell(value) {
  const text = String(value ?? "");
  return `"${text.replaceAll('"', '""')}"`;
}

function fmt(value) {
  return Number(value).toLocaleString("vi-VN", { maximumFractionDigits: 3 });
}

function setStatus(text) {
  statusEl.textContent = text;
}

function setExportEnabled(enabled) {
  exportJsonBtn.disabled = !enabled;
  exportCsvBtn.disabled = !enabled;
  exportPerformanceCsvBtn.disabled = !enabled;
  exportTxtBtn.disabled = !enabled;
}

function escapeHtml(value) {
  return value.replace(/[&<>"']/g, char => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#039;"
  }[char]));
}
