$ErrorActionPreference = "Stop"
if (!(Test-Path "out")) {
    New-Item -ItemType Directory -Path "out" | Out-Null
}
$requestedPort = if ($args.Count -gt 0) { [int]$args[0] } else { 8080 }
$port = $requestedPort
while ($true) {
    $listener = $null
    try {
        $listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback, $port)
        $listener.Start()
        break
    } catch {
        Write-Host "Port $port dang ban, thu port $($port + 1)..."
        $port++
    } finally {
        if ($listener -ne $null) {
            $listener.Stop()
        }
    }
}
javac -encoding UTF-8 -d out src\piHAUPA\*.java
Write-Host "Mo trinh duyet tai: http://localhost:$port/"
java -cp out piHAUPA.Main --web $port
