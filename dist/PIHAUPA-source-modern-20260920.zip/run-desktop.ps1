$ErrorActionPreference = "Stop"

if (!(Test-Path "out")) {
    New-Item -ItemType Directory -Path "out" | Out-Null
}

javac -encoding UTF-8 -d out src\piHAUPA\*.java
if ($LASTEXITCODE -ne 0) { throw "Java compilation failed with exit code $LASTEXITCODE" }
java -Xms256m -Xmx4g -cp out piHAUPA.DesktopApp
if ($LASTEXITCODE -ne 0) { throw "Desktop app exited with code $LASTEXITCODE" }
