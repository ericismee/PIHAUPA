$ErrorActionPreference = "Stop"

$packageRoot = "build\desktop-package"
$buildStamp = [DateTime]::Now.ToString('yyyyMMdd-HHmmss')
$inputRoot = "$packageRoot\input-$buildStamp"
$classRoot = "$packageRoot\classes-$buildStamp"
$destinationRoot = "$packageRoot\app-$buildStamp"

if (Test-Path "$destinationRoot\PIHAUPA Desktop") {
    throw "Gói desktop đã tồn tại. Hãy đổi tên hoặc xóa build\desktop-package\app\PIHAUPA Desktop trước khi đóng gói lại."
}

New-Item -ItemType Directory -Force -Path $inputRoot, $classRoot, $destinationRoot | Out-Null
javac -encoding UTF-8 -d $classRoot src\piHAUPA\*.java
if ($LASTEXITCODE -ne 0) { throw "Java compilation failed with exit code $LASTEXITCODE" }
jar --create --file "$inputRoot\PIHAUPA.jar" --main-class piHAUPA.DesktopApp -C $classRoot .
if ($LASTEXITCODE -ne 0) { throw "JAR packaging failed with exit code $LASTEXITCODE" }

jpackage `
    --type app-image `
    --name "PIHAUPA Desktop" `
    --input $inputRoot `
    --main-jar PIHAUPA.jar `
    --main-class piHAUPA.DesktopApp `
    --java-options "-Xms256m" `
    --java-options "-Xmx4g" `
    --dest $destinationRoot
if ($LASTEXITCODE -ne 0) { throw "Desktop packaging failed with exit code $LASTEXITCODE" }

Write-Host "Đã tạo ứng dụng tại: $destinationRoot\PIHAUPA Desktop"
