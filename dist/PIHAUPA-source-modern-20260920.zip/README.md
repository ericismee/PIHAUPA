# PIHAUPA Java

Chương trình Java cài đặt thuật toán PIHAUPA trong bài báo "Intelligent average utility pattern analysis using pre-large concept in dynamic stream data".

## Chạy nhanh

### Desktop App

```powershell
.\run-desktop.ps1
```

Bản desktop gọi trực tiếp lõi Java, không truyền dữ liệu qua HTTP hoặc giữ bản sao trong `textarea`. Ứng dụng có chọn file PIPA/PIHAUPA, ngưỡng `Su/Sl`, tỷ lệ chia DB0-DB2, giới hạn dòng, chạy nền có thể hủy, bảng time/memory theo số dòng và xuất JSON/CSV/input TXT.

Giao diện desktop có cột thiết lập bên trái và kết quả bên phải. Dữ liệu ví dụ được chọn sẵn để thử bằng một lần bấm. Ba thẻ chỉ số hiển thị số giao dịch, số lần quét lại và thời gian; thẻ Tổng quan trình bày DB0–DB2 thành từng thẻ giải thích điều kiện re-scan. Các mục Hiệu năng, Mẫu tìm được, Nhật ký và Hướng dẫn giúp xem từng loại thông tin riêng; bảng có thể sắp xếp theo cột.

Dùng nhanh: bấm **Dùng dữ liệu ví dụ** → **Chạy PIHAUPA** → xem thẻ **Tổng quan** hoặc **Thời gian và bộ nhớ** → **Xuất kết quả**. Nếu dùng `all_data.txt` PIPA, bấm **Ngưỡng gợi ý PIPA** (Su=0.02, Sl=0.01); mức 0.23/0.10 của ví dụ bài báo có thể không tìm thấy mẫu trên PIPA. Nếu không chọn thư mục xuất, kết quả được lưu trong `Documents\PIHAUPA Desktop\pihaupa-ngày-giờ`. Thẻ **Hướng dẫn** giải thích các chỉ số và việc chuyển dữ liệu PIPA.

Thẻ **Tổng quan** tách kết quả của mỗi batch thành bốn phần: dữ liệu mới, ngưỡng phân loại mẫu, điều kiện re-scan và kết quả. `ID` là dữ liệu thêm kể từ lần quét toàn bộ gần nhất; `OD` là dữ liệu tại lần quét đó. PIHAUPA quét lại khi `MU(ID) - Su × TU(ID) ≥ (Su - Sl) × TU(OD)` (bằng ngưỡng cũng quét lại). Nếu không đạt, app chỉ cập nhật các mẫu đang giữ. Điều kiện cũ của bài báo được hiển thị riêng để so sánh, không dùng để quyết định. Trong file `performance-by-rows.csv`, hai cột `tightLeftMUminusSuTU` và `tightRightSuMinusSlTimesOldTU` cho biết hai vế của phép so sánh.

Đóng gói thành ứng dụng Windows tự chứa runtime Java:

```powershell
.\package-desktop.ps1
```

App image được tạo trong `build\desktop-package\app-YYYYMMDD-HHMMSS\PIHAUPA Desktop` và có thể mở bằng `PIHAUPA Desktop.exe`. Mỗi lần đóng gói dùng một thư mục mới để không ghi đè gói cũ.

### Web UI

```powershell
.\run-web.ps1
```

Mở trình duyệt tại địa chỉ mà script in ra, ví dụ:

```text
http://localhost:8080/
```

Nếu port đang bận, script sẽ tự thử port kế tiếp. Web UI cho phép nhập input, tải file mẫu `.txt` lên, chỉnh ngưỡng `Su/Sl`, chọn tỷ lệ tách PIPA thành đúng ba tập `DB0/DB1/DB2`, xem dữ liệu theo từng cột batch và xuất JSON, CSV pattern, CSV hiệu năng hoặc TXT.

## Dùng File PIPA Dataset

Repo `coallaoh/PIPA_dataset` chứa metadata ảnh/người, không phải dữ liệu utility transaction trực tiếp. Web UI có bộ chuyển đổi tự động khi tải file PIPA lên:

- Mỗi `photo_id` được xem như một transaction.
- Mỗi `identity_id` được xem như một item, đặt tên dạng `P1`, `P2`, ...
- `internal utility` được tính bằng diện tích bounding box `width x height`.
- `external utility` mặc định bằng `1` cho mọi identity.
- Các ảnh (transaction) được giữ theo thứ tự xuất hiện và chia thành đúng ba batch `DB0`, `DB1`, `DB2`.
- Tỷ lệ mặc định là `60,20,20`; có thể thay đổi trên Web UI hoặc bằng `--split A,B,C` ở CLI.

Đây là cách ánh xạ để đưa PIPA vào PIHAUPA. Về mặt ý nghĩa, kết quả khi đó phản ánh các mẫu người thường xuất hiện cùng ảnh với mức đóng góp theo kích thước bounding box, không phải utility thương mại như ví dụ trong bài báo.

### CLI

```powershell
.\run.ps1 examples\sample.txt
```

Đọc trực tiếp PIPA, giới hạn 10.000 dòng annotation để thử nhanh, chia ba tập và xuất toàn bộ file:

```powershell
javac -encoding UTF-8 -d out src\piHAUPA\*.java
java -Xmx2g -cp out piHAUPA.Main `
  --pipa "C:\duong-dan\PIPA_dataset-main\all_data.txt" `
  --su 0.23 --sl 0.10 --split 60,20,20 --max-rows 10000 `
  --summary --output-dir results\pipa
```

Bỏ `--max-rows` hoặc đặt `0` để đọc toàn bộ file. Chương trình cũng tự nhận diện metadata PIPA khi dùng `--input` hoặc truyền đường dẫn file trực tiếp.

Tạo dữ liệu synthetic lớn khoảng 100.000 transaction:

```powershell
.\generate-synthetic.ps1 100000 30 4 10
.\run.ps1 examples\synthetic-100000.txt
```

Preset dữ liệu lớn dùng `Su=0.02`, `Sl=0.01`. Nếu máy chạy quá lâu, tăng hai ngưỡng này hoặc giảm số item/giao dịch.

Chạy benchmark gọn, chỉ in thống kê thay vì in toàn bộ pattern:

```powershell
.\run-benchmark.ps1 100000 30 4 10
```

Hoặc tự biên dịch:

```powershell
javac -encoding UTF-8 -d out src\piHAUPA\*.java
java -cp out piHAUPA.Main examples\sample.txt
```

Nếu không truyền file input, chương trình tự chạy bộ dữ liệu mẫu trong bài báo.

## Định Dạng Input

```text
upper=0.23
lower=0.10

external:
A=2 B=5 C=1 D=3 E=6 F=4

batch DB0
T1: A:2 B:1 C:3
T2: C:1 D:2

batch DB1
T3: A:3 F:3
```

- `upper` là ngưỡng trên `Su`.
- `lower` là ngưỡng dưới `Sl`.
- `external` là external utility của từng item.
- Mỗi `batch` đại diện cho DB0, DB1, DB2... trong môi trường stream insertion.
- Mỗi transaction dùng dạng `TID: item:internalUtility ...`.

## Chú Thích Chỉ Số

- Bài báo dùng hai ngưỡng chính: `Su` (upper threshold ratio) và `Sl` (lower threshold ratio), với điều kiện `0 < Sl < Su`.
- Ví dụ minh họa trong bài báo dùng `Su = 0.23` và `Sl = 0.10`.
- `AU`: Average Utility, lợi ích trung bình của pattern.
- `TU`: Transaction Utility, tổng lợi ích của giao dịch hoặc tập giao dịch.
- `MU`: Maximum Utility, tổng lợi ích lớn nhất trong từng giao dịch, dùng cho tight re-scan.
- `minUtil trên`: `Su x Tổng TU`, ngưỡng để pattern trở thành `LARGE/HAUP`.
- `minUtil dưới`: `Sl x Tổng TU`, ngưỡng để pattern được giữ ở nhóm `PRE-LARGE`.
- `LARGE/HAUP`: pattern đạt ngưỡng trên, là kết quả chính.
- `PRE-LARGE`: pattern nằm giữa ngưỡng dưới và ngưỡng trên, được lưu để cập nhật khi có batch mới.
- `Quét lại`: khi dữ liệu mới đủ lớn theo điều kiện tight re-scan, chương trình dựng lại cây pattern từ toàn bộ dữ liệu tích lũy.

## Output

Chương trình in/hiển thị:

- Kết quả HAUP sau từng batch.
- Các mẫu pre-large/large đang được quản lý.
- Tổng utility `TU`, tổng maximum utility `MU`.
- Điều kiện tight re-scan, số lần re-scan.
- Thời gian chạy, bộ nhớ heap tăng thêm, số ứng viên/list node/pattern được duyệt.
- Chú thích rõ ràng cho `AU`, `TU`, `MU`, `minUtil`, `LARGE/HAUP`, `PRE-LARGE`.

Khi có `--output-dir`, chương trình tạo:

- `pihaupa-input.txt`: input chuẩn hóa, có cả DB0-DB2.
- `splits/DB0.txt`, `splits/DB1.txt`, `splits/DB2.txt`: ba tập độc lập.
- `report.json`: toàn bộ kết quả và chẩn đoán re-scan.
- `patterns.csv`: các mẫu LARGE/PRE-LARGE theo batch.
- `performance-by-rows.csv`: thời gian, heap trước/sau/đỉnh, TU/MU và quyết định re-scan theo số dòng batch và số dòng tích lũy.

## Kiểm thử tính đúng

```powershell
.\run-tests.ps1
```

Bộ kiểm thử đối chiếu HAUP của PIHAUPA với khai phá vét cạn sau từng batch của ví dụ bài báo; kiểm tra DB1 không re-scan, DB2 có re-scan; kiểm tra cập nhật transaction rộng qua cây prefix; và kiểm tra input không hợp lệ. Nhánh không re-scan chỉ đi theo các pattern đang quản lý, không sinh toàn bộ `2^n` tập con của giao dịch.
