package piHAUPA;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;

public final class WebServer {
    private static final Path WEB_ROOT = Path.of("web");

    private WebServer() {
    }

    public static void start(int port) throws IOException {
        HttpServer server = HttpServer.create(new InetSocketAddress(port), 0);
        server.createContext("/api/analyze", WebServer::handleAnalyze);
        server.createContext("/", WebServer::handleStatic);
        server.setExecutor(null);
        server.start();
        System.out.printf(Locale.US, "PIHAUPA Web UI running at http://localhost:%d/%n", port);
    }

    private static void handleAnalyze(HttpExchange exchange) throws IOException {
        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            send(exchange, 405, "text/plain; charset=utf-8", "POST only");
            return;
        }
        try {
            String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            InputData input = InputParser.parseText(body);
            AnalysisReport report = AnalysisReport.run(input);
            send(exchange, 200, "application/json; charset=utf-8", report.toJson());
        } catch (Exception ex) {
            send(exchange, 400, "application/json; charset=utf-8",
                    "{\"error\":\"" + escape(ex.getMessage()) + "\"}");
        }
    }

    private static void handleStatic(HttpExchange exchange) throws IOException {
        String rawPath = exchange.getRequestURI().getPath();
        String relative = rawPath.equals("/") ? "index.html" : rawPath.substring(1);
        Path file = WEB_ROOT.resolve(relative).normalize();
        if (!file.startsWith(WEB_ROOT) || !Files.exists(file) || Files.isDirectory(file)) {
            send(exchange, 404, "text/plain; charset=utf-8", "Not found");
            return;
        }
        send(exchange, 200, contentType(file), Files.readAllBytes(file));
    }

    private static String contentType(Path file) {
        String name = file.getFileName().toString().toLowerCase(Locale.ROOT);
        if (name.endsWith(".html")) {
            return "text/html; charset=utf-8";
        }
        if (name.endsWith(".css")) {
            return "text/css; charset=utf-8";
        }
        if (name.endsWith(".js")) {
            return "application/javascript; charset=utf-8";
        }
        return "application/octet-stream";
    }

    private static void send(HttpExchange exchange, int status, String contentType, String body) throws IOException {
        send(exchange, status, contentType, body.getBytes(StandardCharsets.UTF_8));
    }

    private static void send(HttpExchange exchange, int status, String contentType, byte[] body) throws IOException {
        exchange.getResponseHeaders().set("Content-Type", contentType);
        exchange.sendResponseHeaders(status, body.length);
        try (OutputStream stream = exchange.getResponseBody()) {
            stream.write(body);
        }
    }

    private static String escape(String value) {
        if (value == null) {
            return "Unknown error";
        }
        return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}

