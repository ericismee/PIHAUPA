package piHAUPA;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.concurrent.CancellationException;

/** Converts PIPA person-annotation metadata into utility transactions. */
public final class PipaDatasetParser {
    public static final double[] DEFAULT_SPLIT = {0.60, 0.20, 0.20};

    private PipaDatasetParser() {
    }

    public static InputData parse(Path path, double upper, double lower, double[] splitRatios,
                                  long maximumAnnotationRows) throws IOException {
        validateThresholds(upper, lower);
        double[] ratios = validateSplit(splitRatios);
        Map<String, Map<String, Double>> photos = new LinkedHashMap<>();
        Map<String, Double> external = new TreeMap<>();
        long acceptedRows = 0L;
        long physicalLine = 0L;

        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String raw;
            while ((raw = reader.readLine()) != null) {
                physicalLine++;
                if ((physicalLine & 1023L) == 0L && Thread.currentThread().isInterrupted()) {
                    throw new CancellationException("PIPA import cancelled.");
                }
                String line = raw.trim();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                if (maximumAnnotationRows > 0 && acceptedRows >= maximumAnnotationRows) {
                    break;
                }
                String[] columns = line.split("\\s+");
                if (columns.length < 8) {
                    throw new IllegalArgumentException("PIPA line " + physicalLine
                            + " must have at least 8 numeric columns.");
                }
                try {
                    String photoId = columns[1];
                    double width = Math.max(1.0, Double.parseDouble(columns[4]));
                    double height = Math.max(1.0, Double.parseDouble(columns[5]));
                    String item = "P" + columns[6];
                    double internalUtility = width * height;
                    if (!Double.isFinite(internalUtility)) {
                        throw new NumberFormatException("non-finite bounding-box area");
                    }
                    photos.computeIfAbsent(photoId, ignored -> new TreeMap<>())
                            .merge(item, internalUtility, Double::sum);
                    external.put(item, 1.0);
                    acceptedRows++;
                } catch (NumberFormatException ex) {
                    throw new IllegalArgumentException("Invalid numeric value on PIPA line " + physicalLine, ex);
                }
            }
        }

        if (photos.isEmpty()) {
            throw new IllegalArgumentException("No PIPA annotation rows were found in " + path);
        }

        List<Transaction> transactions = new ArrayList<>(photos.size());
        photos.forEach((photoId, items) -> transactions.add(new Transaction("T" + photoId, items)));
        int[] counts = splitCounts(transactions.size(), ratios);
        List<Batch> batches = new ArrayList<>(3);
        int from = 0;
        for (int i = 0; i < 3; i++) {
            int to = Math.min(transactions.size(), from + counts[i]);
            batches.add(new Batch("DB" + i, List.copyOf(transactions.subList(from, to))));
            from = to;
        }
        return new InputData(upper, lower, Map.copyOf(external), List.copyOf(batches));
    }

    public static boolean looksLikePipa(Path path) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8)) {
            String raw;
            while ((raw = reader.readLine()) != null) {
                String line = raw.trim();
                if (line.isEmpty() || line.startsWith("#")) {
                    continue;
                }
                String[] columns = line.split("\\s+");
                if (columns.length < 8) {
                    return false;
                }
                for (int i = 0; i < 8; i++) {
                    try {
                        Double.parseDouble(columns[i]);
                    } catch (NumberFormatException ex) {
                        return false;
                    }
                }
                return true;
            }
        }
        return false;
    }

    public static double[] parseSplit(String value) {
        String[] parts = value.split("[,;:]");
        if (parts.length != 3) {
            throw new IllegalArgumentException("Split must contain exactly three ratios, for example 60,20,20.");
        }
        double[] ratios = new double[3];
        for (int i = 0; i < 3; i++) {
            ratios[i] = Double.parseDouble(parts[i].trim());
        }
        return validateSplit(ratios);
    }

    private static int[] splitCounts(int total, double[] ratios) {
        double sum = ratios[0] + ratios[1] + ratios[2];
        int[] counts = new int[3];
        double[] fractions = new double[3];
        int assigned = 0;
        for (int i = 0; i < 3; i++) {
            double exact = total * ratios[i] / sum;
            counts[i] = (int) Math.floor(exact);
            fractions[i] = exact - counts[i];
            assigned += counts[i];
        }
        while (assigned < total) {
            int best = 0;
            for (int i = 1; i < 3; i++) {
                if (fractions[i] > fractions[best]) {
                    best = i;
                }
            }
            counts[best]++;
            fractions[best] = -1.0;
            assigned++;
        }
        if (total >= 3) {
            for (int i = 0; i < 3; i++) {
                if (counts[i] == 0) {
                    int donor = counts[0] >= counts[1] && counts[0] >= counts[2] ? 0
                            : counts[1] >= counts[2] ? 1 : 2;
                    counts[donor]--;
                    counts[i]++;
                }
            }
        }
        return counts;
    }

    private static double[] validateSplit(double[] splitRatios) {
        if (splitRatios == null || splitRatios.length != 3) {
            throw new IllegalArgumentException("Exactly three split ratios are required.");
        }
        double[] copy = splitRatios.clone();
        for (double ratio : copy) {
            if (!Double.isFinite(ratio) || ratio <= 0.0) {
                throw new IllegalArgumentException("All three split ratios must be finite and positive.");
            }
        }
        return copy;
    }

    private static void validateThresholds(double upper, double lower) {
        if (!(lower > 0.0 && lower < upper && upper <= 1.0)) {
            throw new IllegalArgumentException("Thresholds must satisfy 0 < Sl < Su <= 1.");
        }
    }
}
