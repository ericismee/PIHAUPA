package piHAUPA;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JComponent;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Insets;
import java.io.IOException;
import java.io.Serial;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.ArrayList;
import java.util.concurrent.CancellationException;

/** Native Swing front end that calls the PIHAUPA core directly without HTTP or browser copies. */
public final class DesktopApp extends JFrame {
    @Serial
    private static final long serialVersionUID = 1L;
    private static final int DISPLAY_PATTERN_LIMIT = 5_000;
    private static final String BUILT_IN_SAMPLE = "Ví dụ bài báo · DB0–DB2";
    private static final Color NAVY = new Color(25, 45, 68);
    private static final Color TEAL = new Color(0, 130, 126);
    private static final Color PAGE = new Color(244, 247, 250);
    private static final Color BORDER = new Color(216, 225, 233);
    private static final Color MUTED = new Color(92, 108, 123);

    private final JTextField inputField = new JTextField();
    private final JComboBox<String> formatBox = new JComboBox<>(new String[]{"Tự nhận diện", "PIPA", "PIHAUPA"});
    private final JTextField upperField = new JTextField("0.23");
    private final JTextField lowerField = new JTextField("0.10");
    private final JTextField splitField = new JTextField("60,20,20");
    private final JTextField maximumRowsField = new JTextField("0");
    private final JTextField outputField = new JTextField();
    private final JCheckBox autoExportBox = new JCheckBox("Tự xuất sau khi chạy", false);
    private final JButton runButton = new JButton("Chạy PIHAUPA");
    private final JButton sampleButton = new JButton("Dùng dữ liệu ví dụ");
    private final JButton pipaPresetButton = new JButton("Ngưỡng gợi ý PIPA");
    private final JButton cancelButton = new JButton("Hủy");
    private final JButton exportButton = new JButton("Xuất kết quả");
    private final JProgressBar progressBar = new JProgressBar();
    private final JLabel statusLabel = new JLabel("Sẵn sàng");
    private final JPanel overviewPanel = new JPanel();
    private final JTextArea logArea = new JTextArea();
    private final JLabel transactionMetric = new JLabel("—");
    private final JLabel rescanMetric = new JLabel("—");
    private final JLabel timeMetric = new JLabel("—");
    private final CardLayout resultLayout = new CardLayout();
    private final JPanel resultDeck = new JPanel(resultLayout);
    private final List<JButton> resultNavigation = new ArrayList<>();
    private final DefaultTableModel performanceModel = readOnlyModel(
            "Batch", "Dòng batch", "Dòng tích lũy", "Time ms", "Heap sau MB", "Heap đỉnh MB",
            "TU", "MU", "Re-scan", "LARGE", "PRE-LARGE");
    private final DefaultTableModel patternModel = readOnlyModel(
            "Batch", "Loại", "Pattern", "AU", "sumU", "Độ dài");

    private transient SwingWorker<RunResult, String> worker;
    private transient InputData lastInput;
    private transient AnalysisReport lastReport;
    private transient Path lastOutputDirectory;
    private transient boolean exporting;
    private transient volatile Thread runningThread;
    private transient volatile boolean cancelRequested;

    private DesktopApp() {
        super("PIHAUPA Desktop");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1050, 740));
        setSize(1400, 900);
        setLocationRelativeTo(null);
        buildUi();
        wireActions();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // The cross-platform Swing look and feel remains available.
            }
            new DesktopApp().setVisible(true);
        });
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(PAGE);
        setContentPane(root);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(BorderFactory.createEmptyBorder(17, 24, 17, 24));
        JLabel title = new JLabel("PIHAUPA  /  Phân tích mẫu utility");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        JLabel subtitle = new JLabel("Dữ liệu tăng dần  •  điều kiện quét lại  •  hiệu năng theo từng tập");
        subtitle.setForeground(new Color(193, 219, 224));
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        header.add(title, BorderLayout.NORTH);
        header.add(subtitle, BorderLayout.SOUTH);
        root.add(header, BorderLayout.NORTH);

        JPanel workspace = new JPanel(new BorderLayout(16, 0));
        workspace.setBackground(PAGE);
        workspace.setBorder(BorderFactory.createEmptyBorder(18, 20, 16, 20));
        root.add(workspace, BorderLayout.CENTER);

        inputField.setToolTipText("Chọn file PIPA all_data.txt, split_*.txt hoặc file transaction PIHAUPA.");
        upperField.setToolTipText("Mẫu có AU ≥ Su × tổng TU sẽ là LARGE/HAUP.");
        lowerField.setToolTipText("Mẫu có AU ≥ Sl × tổng TU được giữ để cập nhật khi có dữ liệu mới.");
        pipaPresetButton.setToolTipText("Đặt Su=0.02, Sl=0.01 để dễ thấy mẫu trên all_data.txt; 0 < Sl < Su ≤ 1.");
        splitField.setToolTipText("Ba tỷ lệ dương; ví dụ 60,20,20. Chỉ áp dụng cho PIPA.");
        maximumRowsField.setToolTipText("0 đọc toàn bộ file. Hữu ích khi muốn thử nhanh trước.");
        outputField.setToolTipText("Để trống thì xuất vào Documents/PIHAUPA Desktop. Mỗi lần xuất tạo thư mục riêng.");
        styleField(inputField);
        styleField(upperField);
        styleField(lowerField);
        styleField(splitField);
        styleField(maximumRowsField);
        styleField(outputField);
        formatBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formatBox.setPreferredSize(new Dimension(180, 36));
        styleButton(sampleButton, false);
        styleButton(pipaPresetButton, false);

        JPanel configBody = new JPanel();
        configBody.setBackground(Color.WHITE);
        configBody.setLayout(new BoxLayout(configBody, BoxLayout.Y_AXIS));
        configBody.setBorder(BorderFactory.createEmptyBorder(0, 2, 0, 2));
        JLabel configTitle = sectionTitle("Thiết lập phân tích");
        configTitle.setFont(new Font("Segoe UI", Font.BOLD, 19));
        addVertical(configBody, configTitle, 4);
        addVertical(configBody, mutedLabel("Chọn dữ liệu và ngưỡng trước khi chạy."), 12);

        JPanel inputRow = new JPanel(new BorderLayout(8, 0));
        inputRow.setBackground(Color.WHITE);
        inputRow.add(inputField, BorderLayout.CENTER);
        inputRow.add(button("Duyệt...", this::chooseInput), BorderLayout.EAST);
        addVertical(configBody, fieldGroup("FILE DỮ LIỆU", inputRow), 8);
        addVertical(configBody, sampleButton, 18);
        addVertical(configBody, fieldGroup("ĐỊNH DẠNG", formatBox), 12);

        JPanel thresholds = new JPanel(new GridLayout(1, 2, 10, 0));
        thresholds.setBackground(Color.WHITE);
        thresholds.add(fieldGroup("Su · ngưỡng kết quả", upperField));
        thresholds.add(fieldGroup("Sl · ngưỡng giữ mẫu", lowerField));
        addVertical(configBody, thresholds, 8);
        addVertical(configBody, pipaPresetButton, 12);

        addVertical(configBody, mutedLabel("PIPA · chỉ dùng khi chọn dữ liệu PIPA"), 8);
        JPanel splitting = new JPanel(new GridLayout(1, 2, 10, 0));
        splitting.setBackground(Color.WHITE);
        splitting.add(fieldGroup("TỶ LỆ DB0, DB1, DB2", splitField));
        splitting.add(fieldGroup("GIỚI HẠN DÒNG · 0 = tất cả", maximumRowsField));
        addVertical(configBody, splitting, 12);

        JPanel outputRow = new JPanel(new BorderLayout(8, 0));
        outputRow.setBackground(Color.WHITE);
        outputRow.add(outputField, BorderLayout.CENTER);
        outputRow.add(button("Duyệt...", this::chooseOutput), BorderLayout.EAST);
        addVertical(configBody, fieldGroup("THƯ MỤC LƯU KẾT QUẢ", outputRow), 6);
        addVertical(configBody, mutedLabel("Để trống để lưu trong Documents/PIHAUPA Desktop."), 0);

        JScrollPane configScroll = scroll(configBody);
        configScroll.setBorder(BorderFactory.createEmptyBorder());
        configScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
        configScroll.getVerticalScrollBar().setUnitIncrement(16);
        JPanel configCard = new JPanel(new BorderLayout());
        configCard.setBackground(Color.WHITE);
        configCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(20, 20, 20, 20)));
        configCard.add(configScroll, BorderLayout.CENTER);
        configCard.setPreferredSize(new Dimension(390, 0));
        workspace.add(configCard, BorderLayout.WEST);

        JPanel controls = new JPanel(new BorderLayout(0, 9));
        controls.setBackground(Color.WHITE);
        controls.setBorder(BorderFactory.createEmptyBorder(15, 2, 0, 2));
        styleButton(runButton, true);
        styleButton(cancelButton, false);
        styleButton(exportButton, false);
        runButton.setPreferredSize(new Dimension(0, 42));
        controls.add(runButton, BorderLayout.NORTH);
        JPanel secondaryActions = new JPanel(new GridLayout(1, 2, 9, 0));
        secondaryActions.setBackground(Color.WHITE);
        cancelButton.setEnabled(false);
        exportButton.setEnabled(false);
        secondaryActions.add(cancelButton);
        secondaryActions.add(exportButton);
        controls.add(secondaryActions, BorderLayout.CENTER);
        autoExportBox.setBackground(Color.WHITE);
        autoExportBox.setForeground(MUTED);
        autoExportBox.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        controls.add(autoExportBox, BorderLayout.SOUTH);
        configCard.add(controls, BorderLayout.SOUTH);

        overviewPanel.setLayout(new BoxLayout(overviewPanel, BoxLayout.Y_AXIS));
        overviewPanel.setBackground(Color.WHITE);
        overviewPanel.setBorder(BorderFactory.createEmptyBorder(18, 18, 18, 18));
        showOverviewMessage("Dữ liệu ví dụ đã sẵn sàng. Bấm Chạy PIHAUPA để xem kết quả.");
        logArea.setEditable(false);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setMargin(new Insets(16, 18, 16, 18));
        JTable performanceTable = new JTable(performanceModel);
        performanceTable.setAutoCreateRowSorter(true);
        styleTable(performanceTable);
        performanceTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int[] performanceWidths = {90, 105, 120, 95, 110, 110, 90, 90, 95, 85, 105};
        for (int i = 0; i < performanceWidths.length; i++) {
            performanceTable.getColumnModel().getColumn(i).setPreferredWidth(performanceWidths[i]);
        }
        performanceTable.getColumnModel().getColumn(8).setCellRenderer(statusRenderer());
        JTable patternTable = new JTable(patternModel);
        patternTable.setAutoCreateRowSorter(true);
        styleTable(patternTable);
        patternTable.getColumnModel().getColumn(1).setCellRenderer(statusRenderer());

        JTextArea helpArea = new JTextArea("""
                CÁCH DÙNG NHANH

                1. Bấm “Dùng dữ liệu ví dụ” để thử ngay, hoặc chọn file của bạn.
                2. Chỉnh Su và Sl nếu cần. Với PIPA, có thể bấm “Ngưỡng gợi ý PIPA”.
                   Điều kiện hợp lệ: 0 < Sl < Su ≤ 1.
                3. Bấm “Chạy PIHAUPA”. Kết quả xuất hiện ở các thẻ bên cạnh.
                4. Bấm “Xuất kết quả” để lưu CSV, JSON và ba tập dữ liệu DB0–DB2.

                GIẢI THÍCH NGẮN

                DB0 là dữ liệu ban đầu; DB1 và DB2 là hai đợt dữ liệu mới.
                LARGE/HAUP là mẫu đạt ngưỡng Su, tức kết quả chính.
                PRE-LARGE là mẫu chưa đạt Su nhưng đạt Sl; thuật toán giữ lại để cập nhật nhanh.
                AU là lợi ích trung bình của mẫu. TU là tổng utility, MU là utility lớn nhất mỗi giao dịch.
                Re-scan = Có nghĩa là thuật toán cần đọc lại toàn bộ dữ liệu và xây dựng lại cây mẫu.
                Điều kiện re-scan: MU(ID) - Su × TU(ID) ≥ (Su - Sl) × TU(OD).
                ID là dữ liệu thêm kể từ lần quét toàn bộ gần nhất; OD là dữ liệu tại lần quét đó.
                Nếu hai vế bằng nhau, thuật toán vẫn quét lại. Điều kiện cũ chỉ hiển thị để so sánh,
                không quyết định việc quét lại của PIHAUPA.

                Với PIPA, mỗi ảnh là một giao dịch, mỗi người là một item. Diện tích bounding box
                (rộng × cao) được dùng làm utility nội tại. Đây là quy ước chuyển đổi để minh họa,
                không phải utility kinh doanh trong bài báo.

                Cột “Dòng tích lũy” đếm transaction/ảnh, không phải số annotation thô của PIPA.
                “Heap đỉnh” là giá trị cao nhất quan sát ở các mốc batch, không phải đỉnh liên tục.
                """);
        helpArea.setEditable(false);
        helpArea.setFont(new Font("Consolas", Font.PLAIN, 13));
        helpArea.setMargin(new Insets(18, 20, 18, 20));
        resultDeck.setBackground(Color.WHITE);
        JScrollPane overviewScroll = scroll(overviewPanel);
        overviewScroll.getVerticalScrollBar().setUnitIncrement(18);
        resultDeck.add(overviewScroll, "Tổng quan");
        resultDeck.add(scroll(performanceTable), "Hiệu năng");
        resultDeck.add(scroll(patternTable), "Mẫu tìm được");
        resultDeck.add(scroll(logArea), "Nhật ký");
        resultDeck.add(scroll(helpArea), "Hướng dẫn");

        JPanel resultTop = new JPanel(new BorderLayout(0, 18));
        resultTop.setBackground(Color.WHITE);
        JPanel resultHeading = new JPanel(new BorderLayout(0, 4));
        resultHeading.setBackground(Color.WHITE);
        JLabel resultTitle = sectionTitle("Kết quả phân tích");
        resultTitle.setFont(new Font("Segoe UI", Font.BOLD, 19));
        resultHeading.add(resultTitle, BorderLayout.NORTH);
        resultHeading.add(mutedLabel("Theo dõi mẫu, hiệu năng và quyết định quét lại của từng tập."),
                BorderLayout.SOUTH);
        resultTop.add(resultHeading, BorderLayout.NORTH);

        JPanel metrics = new JPanel(new GridLayout(1, 3, 12, 0));
        metrics.setBackground(Color.WHITE);
        metrics.add(metricCard("GIAO DỊCH", transactionMetric));
        metrics.add(metricCard("SỐ LẦN QUÉT LẠI", rescanMetric));
        metrics.add(metricCard("THỜI GIAN", timeMetric));
        resultTop.add(metrics, BorderLayout.CENTER);

        JPanel navigation = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
        navigation.setBackground(Color.WHITE);
        for (String name : List.of("Tổng quan", "Hiệu năng", "Mẫu tìm được", "Nhật ký", "Hướng dẫn")) {
            JButton tab = new JButton(name);
            tab.setUI(new BasicButtonUI());
            tab.setFont(new Font("Segoe UI", Font.BOLD, 13));
            tab.setFocusPainted(false);
            tab.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            tab.setBorder(BorderFactory.createEmptyBorder(9, 12, 9, 12));
            tab.addActionListener(event -> selectResultView(name));
            resultNavigation.add(tab);
            navigation.add(tab);
        }
        selectResultView("Tổng quan");

        JPanel resultCard = new JPanel(new BorderLayout(0, 14));
        resultCard.setBackground(Color.WHITE);
        resultCard.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(20, 20, 20, 20)));
        JPanel topAndNavigation = new JPanel(new BorderLayout(0, 20));
        topAndNavigation.setBackground(Color.WHITE);
        topAndNavigation.add(resultTop, BorderLayout.NORTH);
        topAndNavigation.add(navigation, BorderLayout.SOUTH);
        resultCard.add(topAndNavigation, BorderLayout.NORTH);
        resultCard.add(resultDeck, BorderLayout.CENTER);
        workspace.add(resultCard, BorderLayout.CENTER);

        JPanel footer = new JPanel(new BorderLayout(12, 0));
        footer.setBackground(Color.WHITE);
        footer.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER),
                BorderFactory.createEmptyBorder(8, 20, 8, 20)));
        progressBar.setIndeterminate(false);
        progressBar.setStringPainted(true);
        progressBar.setString("Sẵn sàng");
        progressBar.setForeground(TEAL);
        progressBar.setPreferredSize(new Dimension(130, 25));
        footer.add(progressBar, BorderLayout.CENTER);
        statusLabel.setForeground(MUTED);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 0));
        footer.add(statusLabel, BorderLayout.EAST);
        root.add(footer, BorderLayout.SOUTH);

        inputField.setText(BUILT_IN_SAMPLE);
        formatBox.setSelectedItem("PIHAUPA");
    }

    private void wireActions() {
        runButton.addActionListener(event -> startRun());
        sampleButton.addActionListener(event -> useSample());
        pipaPresetButton.addActionListener(event -> {
            upperField.setText("0.02");
            lowerField.setText("0.01");
            statusLabel.setText("Đã đặt Su=0.02, Sl=0.01 cho PIPA");
        });
        cancelButton.addActionListener(event -> cancelRun());
        exportButton.addActionListener(event -> exportResult(true));
    }

    private void useSample() {
        inputField.setText(BUILT_IN_SAMPLE);
        formatBox.setSelectedItem("PIHAUPA");
        upperField.setText("0.23");
        lowerField.setText("0.10");
        statusLabel.setText("Đã chọn dữ liệu ví dụ - bấm Chạy PIHAUPA");
    }

    private void startRun() {
        if (worker != null && !worker.isDone()) {
            return;
        }
        RunOptions options;
        try {
            options = readOptions();
        } catch (RuntimeException ex) {
            showError(ex.getMessage());
            return;
        }

        setRunning(true);
        clearResults();
        cancelRequested = false;
        appendLog(options.inputPath == null ? "Đang dùng dữ liệu ví dụ tích hợp."
                : "Bắt đầu đọc " + options.inputPath.toAbsolutePath());
        worker = new SwingWorker<>() {
            @Override
            protected RunResult doInBackground() throws Exception {
                runningThread = Thread.currentThread();
                try {
                    checkCancelled();
                    publish("Đang đọc và chuẩn hóa dữ liệu...");
                    InputData input = loadInput(options);
                    checkCancelled();
                    publish("Đã đọc " + input.batches().stream().mapToInt(b -> b.transactions().size()).sum()
                            + " transaction; đang chạy PIHAUPA...");
                    AnalysisReport report = AnalysisReport.run(input);
                    checkCancelled();
                    return new RunResult(input, report, options.outputDirectory);
                } finally {
                    runningThread = null;
                }
            }

            @Override
            protected void process(List<String> chunks) {
                chunks.forEach(DesktopApp.this::appendLog);
                if (!chunks.isEmpty()) {
                    statusLabel.setText(chunks.get(chunks.size() - 1));
                }
            }

            @Override
            protected void done() {
                try {
                    RunResult result = get();
                    lastInput = result.input;
                    lastReport = result.report;
                    lastOutputDirectory = result.outputDirectory;
                    renderReport(result.report);
                    selectResultView("Tổng quan");
                    exportButton.setEnabled(true);
                    appendLog("Hoàn tất thuật toán.");
                    if (autoExportBox.isSelected()) {
                        exportResult(false);
                    }
                    statusLabel.setText("Hoàn tất");
                } catch (CancellationException ex) {
                    appendLog("Đã hủy tác vụ.");
                    statusLabel.setText("Đã hủy");
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    if (cause instanceof CancellationException || cause instanceof InterruptedException
                            || cancelRequested) {
                        appendLog("Đã hủy tác vụ.");
                        statusLabel.setText("Đã hủy");
                    } else {
                        appendLog("Lỗi: " + cause.getMessage());
                        showError(cause.getMessage());
                        statusLabel.setText("Có lỗi");
                    }
                } finally {
                    setRunning(false);
                }
            }

            private void checkCancelled() {
                if (cancelRequested || Thread.currentThread().isInterrupted()) {
                    throw new CancellationException();
                }
            }
        };
        worker.execute();
    }

    private InputData loadInput(RunOptions options) throws IOException {
        if (options.inputPath == null) {
            InputData builtIn = InputParser.parseBuiltInSample();
            return new InputData(options.upper, options.lower, builtIn.externalUtilities(), builtIn.batches());
        }
        boolean pipa = switch (options.format) {
            case "PIPA" -> true;
            case "PIHAUPA" -> false;
            default -> PipaDatasetParser.looksLikePipa(options.inputPath);
        };
        if (pipa) {
            return PipaDatasetParser.parse(options.inputPath, options.upper, options.lower,
                    options.splitRatios, options.maximumRows);
        }
        InputData parsed = InputParser.parse(options.inputPath);
        return new InputData(options.upper, options.lower, parsed.externalUtilities(), parsed.batches());
    }

    private RunOptions readOptions() {
        if (inputField.getText().isBlank()) {
            throw new IllegalArgumentException("Hãy chọn file dữ liệu.");
        }
        Path input = BUILT_IN_SAMPLE.equals(inputField.getText().trim())
                ? null : Path.of(inputField.getText().trim());
        double upper = parseRatio(upperField.getText(), "Su");
        double lower = parseRatio(lowerField.getText(), "Sl");
        if (!(lower > 0.0 && lower < upper && upper <= 1.0)) {
            throw new IllegalArgumentException("Ngưỡng phải thỏa 0 < Sl < Su <= 1.");
        }
        long maximumRows;
        try {
            maximumRows = Long.parseLong(maximumRowsField.getText().trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException("Giới hạn dòng phải là số nguyên, ví dụ 0 hoặc 10000.", ex);
        }
        if (maximumRows < 0) {
            throw new IllegalArgumentException("Giới hạn dòng không được âm.");
        }
        Path output = outputField.getText().isBlank()
                ? Path.of(System.getProperty("user.home"), "Documents", "PIHAUPA Desktop")
                : Path.of(outputField.getText().trim());
        return new RunOptions(input, String.valueOf(formatBox.getSelectedItem()), upper, lower,
                PipaDatasetParser.parseSplit(splitField.getText().trim()), maximumRows, output);
    }

    private void cancelRun() {
        if (worker != null) {
            cancelRequested = true;
            Thread thread = runningThread;
            if (thread != null) {
                thread.interrupt();
            }
            cancelButton.setEnabled(false);
            statusLabel.setText("Đang hủy...");
        }
    }

    private void exportResult(boolean showDialog) {
        if (lastInput == null || lastReport == null || exporting) {
            return;
        }
        Path parent = outputField.getText().isBlank() ? lastOutputDirectory : Path.of(outputField.getText().trim());
        Path destination = parent.resolve("pihaupa-" + LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS")));
        InputData input = lastInput;
        AnalysisReport report = lastReport;
        exporting = true;
        exportButton.setEnabled(false);
        appendLog("Đang xuất kết quả vào " + destination.toAbsolutePath());
        new SwingWorker<Path, Void>() {
            @Override
            protected Path doInBackground() throws Exception {
                InputWriter.writeCombined(input, destination.resolve("pihaupa-input.txt"));
                if (input.batches().size() == 3) {
                    InputWriter.writeThreeSplitFiles(input, destination.resolve("splits"));
                }
                ReportWriter.writeAll(report, destination);
                return destination;
            }

            @Override
            protected void done() {
                exporting = false;
                exportButton.setEnabled(lastReport != null);
                try {
                    Path exported = get();
                    appendLog("Đã xuất kết quả: " + exported.toAbsolutePath());
                    if (showDialog) {
                        JOptionPane.showMessageDialog(DesktopApp.this, "Đã xuất vào:\n" + exported.toAbsolutePath(),
                                "PIHAUPA", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    showError("Không thể xuất kết quả: " + cause.getMessage());
                }
            }
        }.execute();
    }

    private void renderReport(AnalysisReport report) {
        transactionMetric.setText(String.format(Locale.US, "%,d", report.transactionCount()));
        rescanMetric.setText(Long.toString(report.stats().rescanCount()));
        timeMetric.setText(String.format(Locale.US, "%.1f ms", report.elapsedNanos() / 1_000_000.0));
        overviewPanel.removeAll();
        JLabel heading = sectionTitle("Diễn biến theo từng tập dữ liệu");
        heading.setFont(new Font("Segoe UI", Font.BOLD, 16));
        addVertical(overviewPanel, heading, 5);
        addVertical(overviewPanel, mutedLabel(String.format(Locale.US,
                "Su = %.2f  ·  Sl = %.2f  ·  %d tập dữ liệu  ·  heap đỉnh %.2f MB",
                report.upperThreshold(), report.lowerThreshold(), report.batchCount(),
                report.peakMemoryBytes() / (1024.0 * 1024.0))), 16);

        performanceModel.setRowCount(0);
        for (AnalysisReport.BatchView batch : report.batches()) {
            performanceModel.addRow(new Object[]{batch.name(), batch.transactionCount(),
                    batch.cumulativeTransactionCount(), decimal(batch.elapsedMs()), decimal(batch.memoryAfterMb()),
                    decimal(batch.peakMemoryMb()), decimal(batch.batchTransactionUtility()),
                    decimal(batch.batchMaximumUtility()), batch.rescanTriggered() ? "Có" : "Không", batch.largePatterns().size(),
                    batch.preLargePatterns().size()});
            addVertical(overviewPanel, batchCard(report, batch), 12);
        }
        AnalysisReport.BatchView finalBatch = report.batches().get(report.batches().size() - 1);
        if (finalBatch.largePatterns().isEmpty() && finalBatch.preLargePatterns().isEmpty()) {
            addVertical(overviewPanel, mutedLabel("Không có mẫu đạt ngưỡng. Hãy thử giảm Su/Sl; với PIPA, dùng nút Ngưỡng gợi ý PIPA."), 0);
        }
        overviewPanel.revalidate();
        overviewPanel.repaint();

        patternModel.setRowCount(0);
        AnalysisReport.BatchView lastBatch = report.batches().get(report.batches().size() - 1);
        int displayed = 0;
        for (PatternResult pattern : concat(lastBatch.largePatterns(), lastBatch.preLargePatterns())) {
            if (displayed++ >= DISPLAY_PATTERN_LIMIT) {
                break;
            }
            patternModel.addRow(new Object[]{lastBatch.name(), pattern.type(), pattern.displayName(),
                    decimal(pattern.averageUtility()), decimal(pattern.sumUtility()), pattern.length()});
        }
        if (displayed > DISPLAY_PATTERN_LIMIT) {
            appendLog("Bảng pattern đã giới hạn " + DISPLAY_PATTERN_LIMIT + " dòng; CSV vẫn xuất đầy đủ.");
        }
    }

    private static JPanel batchCard(AnalysisReport report, AnalysisReport.BatchView batch) {
        JPanel card = new JPanel(new BorderLayout(0, 10));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(14, 16, 14, 16)));
        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(Color.WHITE);
        JLabel name = sectionTitle(batch.name() + "  ·  " + batch.transactionCount() + " giao dịch mới");
        JLabel badge = new JLabel(batch.tightRescanLimit() == null ? "KHỞI TẠO"
                : batch.rescanTriggered() ? "QUÉT LẠI" : "CHỈ CẬP NHẬT");
        badge.setOpaque(true);
        badge.setBackground(batch.rescanTriggered() ? new Color(224, 245, 239) : new Color(237, 243, 247));
        badge.setForeground(batch.rescanTriggered() ? new Color(0, 105, 83) : NAVY);
        badge.setFont(new Font("Segoe UI", Font.BOLD, 11));
        badge.setBorder(BorderFactory.createEmptyBorder(5, 9, 5, 9));
        top.add(name, BorderLayout.WEST);
        top.add(badge, BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);

        JPanel details = new JPanel();
        details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
        details.setBackground(Color.WHITE);
        addVertical(details, mutedLabel(String.format(Locale.US,
                "Tích lũy: %d giao dịch   ·   TU(batch) %.3f   ·   MU(batch) %.3f",
                batch.cumulativeTransactionCount(), batch.batchTransactionUtility(), batch.batchMaximumUtility())), 7);
        addVertical(details, mutedLabel(String.format(Locale.US,
                "Ngưỡng mẫu: LARGE ≥ %.3f   ·   PRE-LARGE từ %.3f đến dưới %.3f",
                batch.minUtilUpper(), batch.minUtilLower(), batch.minUtilUpper())), 10);

        if (batch.tightRescanLimit() == null) {
            addVertical(details, emphasis("DB0 được quét để xây dựng cây mẫu ban đầu.", TEAL), 7);
        } else {
            double oldTu = batch.totalTransactionUtility() - batch.accumulatedTransactionUtility();
            double left = batch.accumulatedMaximumUtility()
                    - report.upperThreshold() * batch.accumulatedTransactionUtility();
            double right = (report.upperThreshold() - report.lowerThreshold()) * oldTu;
            addVertical(details, emphasis(String.format(Locale.US,
                    "Điều kiện re-scan: %.6f %s %.6f  →  %s", left,
                    batch.rescanTriggered() ? "≥" : "<", right,
                    batch.rescanTriggered() ? "quét lại" : "không quét lại"),
                    batch.rescanTriggered() ? TEAL : NAVY), 6);
            addVertical(details, mutedLabel(String.format(Locale.US,
                    "MU(ID) %.3f   ·   TU(ID) %.3f   ·   TU(OD) %.3f",
                    batch.accumulatedMaximumUtility(), batch.accumulatedTransactionUtility(), oldTu)), 5);
            if (batch.tightRescanDenominator() > 0.0) {
                addVertical(details, mutedLabel(String.format(Locale.US,
                        "Công thức bài báo: MU(ID) %.3f so với giới hạn %.3f",
                        batch.accumulatedMaximumUtility(), batch.tightRescanLimit())), 5);
            } else {
                addVertical(details, mutedLabel("Mẫu số công thức chia không dương; đã dùng dạng so sánh an toàn."), 5);
            }
            addVertical(details, mutedLabel(String.format(Locale.US,
                    "Điều kiện cũ chỉ để tham khảo: TU(ID) %.3f so với giới hạn %.3f",
                    batch.accumulatedTransactionUtility(), batch.originalRescanLimit())), 7);
        }
        addVertical(details, emphasis(String.format(Locale.US,
                "Kết quả: %d LARGE  ·  %d PRE-LARGE  ·  %.3f ms",
                batch.largePatterns().size(), batch.preLargePatterns().size(), batch.elapsedMs()), NAVY), 0);
        card.add(details, BorderLayout.CENTER);
        return card;
    }

    private static List<PatternResult> concat(List<PatternResult> first, List<PatternResult> second) {
        java.util.ArrayList<PatternResult> result = new java.util.ArrayList<>(first.size() + second.size());
        result.addAll(first);
        result.addAll(second);
        return result;
    }

    private void chooseInput() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            inputField.setText(chooser.getSelectedFile().getAbsolutePath());
            formatBox.setSelectedItem("Tự nhận diện");
        }
    }

    private static double parseRatio(String text, String name) {
        try {
            return Double.parseDouble(text.trim());
        } catch (NumberFormatException ex) {
            throw new IllegalArgumentException(name + " phải là số thập phân, ví dụ 0.23.", ex);
        }
    }

    private void chooseOutput() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            outputField.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void setRunning(boolean running) {
        runButton.setEnabled(!running);
        cancelButton.setEnabled(running);
        exportButton.setEnabled(!running && !exporting && lastReport != null);
        progressBar.setIndeterminate(running);
        progressBar.setString(running ? "Đang xử lý..." : "Sẵn sàng");
    }

    private void clearResults() {
        lastInput = null;
        lastReport = null;
        lastOutputDirectory = null;
        transactionMetric.setText("—");
        rescanMetric.setText("—");
        timeMetric.setText("—");
        showOverviewMessage("Đang phân tích dữ liệu. Vui lòng chờ kết quả...");
        logArea.setText("");
        performanceModel.setRowCount(0);
        patternModel.setRowCount(0);
        exportButton.setEnabled(false);
    }

    private void appendLog(String message) {
        logArea.append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "  " + message
                + System.lineSeparator());
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message == null ? "Lỗi không xác định" : message,
                "PIHAUPA - lỗi", JOptionPane.ERROR_MESSAGE);
    }

    private void selectResultView(String name) {
        resultLayout.show(resultDeck, name);
        for (JButton tab : resultNavigation) {
            boolean selected = name.equals(tab.getText());
            tab.setBackground(selected ? NAVY : new Color(239, 244, 247));
            tab.setForeground(selected ? Color.WHITE : MUTED);
        }
    }

    private static JPanel metricCard(String caption, JLabel value) {
        JPanel card = new JPanel(new BorderLayout(0, 7));
        card.setBackground(new Color(236, 247, 246));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(203, 229, 226)),
                BorderFactory.createEmptyBorder(13, 15, 13, 15)));
        JLabel name = new JLabel(caption);
        name.setForeground(MUTED);
        name.setFont(new Font("Segoe UI", Font.BOLD, 11));
        value.setForeground(NAVY);
        value.setFont(new Font("Segoe UI", Font.BOLD, 23));
        card.add(name, BorderLayout.NORTH);
        card.add(value, BorderLayout.CENTER);
        return card;
    }

    private static JPanel fieldGroup(String title, JComponent control) {
        JPanel group = new JPanel(new BorderLayout(0, 6));
        group.setBackground(Color.WHITE);
        JLabel caption = new JLabel(title);
        caption.setFont(new Font("Segoe UI", Font.BOLD, 11));
        caption.setForeground(MUTED);
        group.add(caption, BorderLayout.NORTH);
        group.add(control, BorderLayout.CENTER);
        return group;
    }

    private static JLabel mutedLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        label.setForeground(MUTED);
        return label;
    }

    private static JLabel emphasis(String text, Color color) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(color);
        return label;
    }

    private void showOverviewMessage(String message) {
        overviewPanel.removeAll();
        addVertical(overviewPanel, mutedLabel(message), 0);
        overviewPanel.revalidate();
        overviewPanel.repaint();
    }

    private static void addVertical(JPanel parent, JComponent component, int gap) {
        component.setAlignmentX(LEFT_ALIGNMENT);
        component.setMaximumSize(new Dimension(Integer.MAX_VALUE, component.getPreferredSize().height));
        parent.add(component);
        if (gap > 0) {
            parent.add(Box.createVerticalStrut(gap));
        }
    }

    private static JButton button(String label, Runnable action) {
        JButton button = new JButton(label);
        styleButton(button, false);
        button.addActionListener(event -> action.run());
        return button;
    }

    private static void styleButton(JButton button, boolean primary) {
        button.setUI(new BasicButtonUI());
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(primary ? Color.WHITE : NAVY);
        button.setBackground(primary ? TEAL : new Color(237, 243, 247));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(primary ? TEAL : BORDER),
                BorderFactory.createEmptyBorder(7, 13, 7, 13)));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
    }

    private static void styleField(JTextField field) {
        Dimension size = field.getPreferredSize();
        field.setPreferredSize(new Dimension(Math.max(80, size.width), 32));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(NAVY);
        field.setBackground(Color.WHITE);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(3, 8, 3, 8)));
    }

    private static void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setForeground(NAVY);
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(221, 242, 240));
        table.setSelectionForeground(NAVY);
        table.setRowHeight(32);
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(233, 238, 242));
        table.setIntercellSpacing(new Dimension(0, 1));
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setOpaque(true);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 12));
        headerRenderer.setBackground(NAVY);
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        table.getTableHeader().setDefaultRenderer(headerRenderer);
        table.getTableHeader().setBackground(NAVY);
        table.getTableHeader().setPreferredSize(new Dimension(0, 36));
    }

    private static DefaultTableCellRenderer statusRenderer() {
        return new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean selected, boolean focused, int row, int column) {
                super.getTableCellRendererComponent(table, value, selected, focused, row, column);
                if (!selected) {
                    boolean active = "Có".equals(value) || value == PatternType.LARGE;
                    setForeground(active ? TEAL : MUTED);
                    setBackground(Color.WHITE);
                }
                setFont(new Font("Segoe UI", Font.BOLD, 13));
                return this;
            }
        };
    }

    private static JScrollPane scroll(java.awt.Component content) {
        JScrollPane pane = new JScrollPane(content);
        pane.setBorder(BorderFactory.createLineBorder(BORDER));
        pane.getViewport().setBackground(Color.WHITE);
        return pane;
    }

    private static JLabel sectionTitle(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label.setForeground(NAVY);
        return label;
    }

    private static DefaultTableModel readOnlyModel(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private static String decimal(double value) {
        return String.format(Locale.US, "%.3f", value);
    }

    private static String describeAction(String action) {
        return switch (action) {
            case "INITIAL SCAN + PATTERN EXPANSION" -> "Quét ban đầu và xây dựng cây mẫu";
            case "NO RE-SCAN: UPDATE EXISTING PATTERN TREE" -> "Không quét lại; chỉ cập nhật các mẫu đang giữ";
            case "TIGHT RE-SCAN + FULL PATTERN EXPANSION" -> "Điều kiện re-scan thỏa; quét lại toàn bộ dữ liệu";
            default -> action;
        };
    }

    private record RunOptions(Path inputPath, String format, double upper, double lower,
                              double[] splitRatios, long maximumRows, Path outputDirectory) {
    }

    private record RunResult(InputData input, AnalysisReport report, Path outputDirectory) {
    }
}
