package piHAUPA;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.SwingWorker;
import javax.swing.UIManager;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.io.IOException;
import java.io.Serial;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.CancellationException;

/** Native Swing front end that calls the PIHAUPA core directly without HTTP or browser copies. */
public final class DesktopApp extends JFrame {
    @Serial
    private static final long serialVersionUID = 1L;
    private static final int DISPLAY_PATTERN_LIMIT = 5_000;
    private static final String BUILT_IN_SAMPLE = "Ví dụ tích hợp từ bài báo (không cần file)";
    private static final Color NAVY = new Color(25, 45, 68);
    private static final Color TEAL = new Color(0, 130, 126);
    private static final Color PAGE = new Color(244, 247, 250);
    private static final Color BORDER = new Color(216, 225, 233);
    private static final Color MUTED = new Color(92, 108, 123);

    private final JTextField inputField = new JTextField();
    private final JComboBox<String> formatBox = new JComboBox<>(new String[]{"Tự nhận diện", "PIPA", "PIHAUPA"});
    private final JTextField upperField = new JTextField("0.23");
    private final JTextField lowerField = new JTextField("0.10");
    private final JTextField splitField = new JTextField("60,20,20");
    private final JTextField maximumRowsField = new JTextField("0");
    private final JTextField outputField = new JTextField();
    private final JCheckBox autoExportBox = new JCheckBox("Tự xuất sau khi chạy", false);
    private final JButton runButton = new JButton("Chạy PIHAUPA");
    private final JButton sampleButton = new JButton("Dùng dữ liệu ví dụ");
    private final JButton pipaPresetButton = new JButton("Ngưỡng gợi ý PIPA");
    private final JButton cancelButton = new JButton("Hủy");
    private final JButton exportButton = new JButton("Xuất kết quả");
    private final JProgressBar progressBar = new JProgressBar();
    private final JLabel statusLabel = new JLabel("Sẵn sàng");
    private final JTextArea summaryArea = new JTextArea();
    private final JTextArea logArea = new JTextArea();
    private final DefaultTableModel performanceModel = readOnlyModel(
            "Batch", "Dòng batch", "Dòng tích lũy", "Time ms", "Heap sau MB", "Heap đỉnh MB",
            "TU", "MU", "Re-scan", "LARGE", "PRE-LARGE");
    private final DefaultTableModel patternModel = readOnlyModel(
            "Batch", "Loại", "Pattern", "AU", "sumU", "Độ dài");

    private transient SwingWorker<RunResult, String> worker;
    private transient InputData lastInput;
    private transient AnalysisReport lastReport;
    private transient Path lastOutputDirectory;
    private transient boolean exporting;
    private transient volatile Thread runningThread;
    private transient volatile boolean cancelRequested;

    private DesktopApp() {
        super("PIHAUPA Desktop");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(1050, 720));
        setSize(1360, 880);
        setLocationRelativeTo(null);
        buildUi();
        wireActions();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // The cross-platform Swing look and feel remains available.
            }
            new DesktopApp().setVisible(true);
        });
    }

    private void buildUi() {
        JPanel root = new JPanel(new BorderLayout(0, 0));
        root.setBackground(PAGE);
        setContentPane(root);

        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(BorderFactory.createEmptyBorder(17, 24, 17, 24));
        JLabel title = new JLabel("PIHAUPA  /  Phân tích mẫu utility");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        JLabel subtitle = new JLabel("Dữ liệu tăng dần  •  điều kiện quét lại  •  hiệu năng theo từng tập");
        subtitle.setForeground(new Color(193, 219, 224));
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        header.add(title, BorderLayout.NORTH);
        header.add(subtitle, BorderLayout.SOUTH);
        root.add(header, BorderLayout.NORTH);

        JPanel workspace = new JPanel(new BorderLayout(0, 14));
        workspace.setBackground(PAGE);
        workspace.setBorder(BorderFactory.createEmptyBorder(18, 20, 16, 20));
        root.add(workspace, BorderLayout.CENTER);

        JPanel form = new JPanel(new GridBagLayout());
        form.setBackground(Color.WHITE);
        form.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(8, 16, 12, 16)));
        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(6, 5, 6, 5);
        c.fill = GridBagConstraints.HORIZONTAL;
        c.weightx = 0;
        addFormRow(form, c, 0, "File dữ liệu", inputField, button("Chọn file...", this::chooseInput));
        addFormRow(form, c, 1, "Loại file", formatBox, sampleButton);

        JPanel thresholds = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        thresholds.setBackground(Color.WHITE);
        thresholds.add(new JLabel("Su (ngưỡng kết quả)"));
        upperField.setPreferredSize(new Dimension(85, 28));
        thresholds.add(upperField);
        thresholds.add(new JLabel("Sl (ngưỡng giữ mẫu)"));
        lowerField.setPreferredSize(new Dimension(85, 28));
        thresholds.add(lowerField);
        addFormRow(form, c, 2, "Ngưỡng phân loại mẫu", thresholds, pipaPresetButton);

        JPanel splitting = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        splitting.setBackground(Color.WHITE);
        splitting.add(new JLabel("Tỷ lệ DB0, DB1, DB2"));
        splitField.setPreferredSize(new Dimension(110, 28));
        splitting.add(splitField);
        splitting.add(new JLabel("Tối đa dòng PIPA (0 = tất cả)"));
        maximumRowsField.setPreferredSize(new Dimension(100, 28));
        splitting.add(maximumRowsField);
        addFormRow(form, c, 3, "Chia dữ liệu PIPA", splitting, new JLabel("Chỉ áp dụng cho PIPA"));
        addFormRow(form, c, 4, "Thư mục kết quả", outputField, button("Chọn thư mục...", this::chooseOutput));
        inputField.setToolTipText("Chọn file PIPA all_data.txt, split_*.txt hoặc file transaction PIHAUPA.");
        upperField.setToolTipText("Mẫu có AU ≥ Su × tổng TU sẽ là LARGE/HAUP.");
        lowerField.setToolTipText("Mẫu có AU ≥ Sl × tổng TU được giữ để cập nhật khi có dữ liệu mới.");
        pipaPresetButton.setToolTipText("Đặt Su=0.02, Sl=0.01 để dễ thấy mẫu trên all_data.txt; 0 < Sl < Su ≤ 1.");
        splitField.setToolTipText("Ba tỷ lệ dương; ví dụ 60,20,20. Chỉ áp dụng cho PIPA.");
        maximumRowsField.setToolTipText("0 đọc toàn bộ file. Hữu ích khi muốn thử nhanh trước.");
        outputField.setToolTipText("Để trống thì xuất vào Documents/PIHAUPA Desktop. Mỗi lần xuất tạo thư mục riêng.");
        styleField(inputField);
        styleField(upperField);
        styleField(lowerField);
        styleField(splitField);
        styleField(maximumRowsField);
        styleField(outputField);
        formatBox.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        formatBox.setPreferredSize(new Dimension(180, 32));
        styleButton(sampleButton, false);
        styleButton(pipaPresetButton, false);

        JPanel configCard = new JPanel(new BorderLayout(0, 7));
        configCard.setBackground(PAGE);
        configCard.add(sectionTitle("01  Cấu hình dữ liệu và thuật toán"), BorderLayout.NORTH);
        configCard.add(form, BorderLayout.CENTER);
        workspace.add(configCard, BorderLayout.NORTH);

        summaryArea.setEditable(false);
        summaryArea.setFont(new Font("Consolas", Font.PLAIN, 14));
        summaryArea.setMargin(new Insets(18, 20, 18, 20));
        summaryArea.setBackground(Color.WHITE);
        summaryArea.setForeground(NAVY);
        summaryArea.setText("Chọn dữ liệu ví dụ hoặc chọn file, sau đó bấm Chạy PIHAUPA.\n"
                + "Kết quả và điều kiện re-scan của từng batch sẽ hiện tại đây.");
        logArea.setEditable(false);
        logArea.setFont(new Font("Consolas", Font.PLAIN, 12));
        logArea.setMargin(new Insets(16, 18, 16, 18));
        JTable performanceTable = new JTable(performanceModel);
        performanceTable.setAutoCreateRowSorter(true);
        styleTable(performanceTable);
        performanceTable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        int[] performanceWidths = {90, 105, 120, 95, 110, 110, 90, 90, 95, 85, 105};
        for (int i = 0; i < performanceWidths.length; i++) {
            performanceTable.getColumnModel().getColumn(i).setPreferredWidth(performanceWidths[i]);
        }
        performanceTable.getColumnModel().getColumn(8).setCellRenderer(statusRenderer());
        JTable patternTable = new JTable(patternModel);
        patternTable.setAutoCreateRowSorter(true);
        styleTable(patternTable);
        patternTable.getColumnModel().getColumn(1).setCellRenderer(statusRenderer());

        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabs.setBackground(Color.WHITE);
        tabs.addTab("Tổng quan", scroll(summaryArea));
        tabs.addTab("Hiệu năng", scroll(performanceTable));
        tabs.addTab("Mẫu tìm được", scroll(patternTable));
        tabs.addTab("Nhật ký", scroll(logArea));
        JTextArea helpArea = new JTextArea("""
                CÁCH DÙNG NHANH

                1. Bấm “Dùng dữ liệu ví dụ” để thử ngay, hoặc chọn file của bạn.
                2. Chỉnh Su và Sl nếu cần. Với PIPA, có thể bấm “Ngưỡng gợi ý PIPA”.
                   Điều kiện hợp lệ: 0 < Sl < Su ≤ 1.
                3. Bấm “Chạy PIHAUPA”. Kết quả xuất hiện ở các thẻ bên cạnh.
                4. Bấm “Xuất kết quả” để lưu CSV, JSON và ba tập dữ liệu DB0–DB2.

                GIẢI THÍCH NGẮN

                DB0 là dữ liệu ban đầu; DB1 và DB2 là hai đợt dữ liệu mới.
                LARGE/HAUP là mẫu đạt ngưỡng Su, tức kết quả chính.
                PRE-LARGE là mẫu chưa đạt Su nhưng đạt Sl; thuật toán giữ lại để cập nhật nhanh.
                AU là lợi ích trung bình của mẫu. TU là tổng utility, MU là utility lớn nhất mỗi giao dịch.
                Re-scan = Có nghĩa là thuật toán cần đọc lại toàn bộ dữ liệu và xây dựng lại cây mẫu.
                Điều kiện re-scan: MU(ID) - Su × TU(ID) ≥ (Su - Sl) × TU(OD).
                ID là dữ liệu thêm kể từ lần quét toàn bộ gần nhất; OD là dữ liệu tại lần quét đó.
                Nếu hai vế bằng nhau, thuật toán vẫn quét lại. Điều kiện cũ chỉ hiển thị để so sánh,
                không quyết định việc quét lại của PIHAUPA.

                Với PIPA, mỗi ảnh là một giao dịch, mỗi người là một item. Diện tích bounding box
                (rộng × cao) được dùng làm utility nội tại. Đây là quy ước chuyển đổi để minh họa,
                không phải utility kinh doanh trong bài báo.

                Cột “Dòng tích lũy” đếm transaction/ảnh, không phải số annotation thô của PIPA.
                “Heap đỉnh” là giá trị cao nhất quan sát ở các mốc batch, không phải đỉnh liên tục.
                """);
        helpArea.setEditable(false);
        helpArea.setFont(new Font("Consolas", Font.PLAIN, 13));
        helpArea.setMargin(new Insets(18, 20, 18, 20));
        tabs.addTab("Hướng dẫn", scroll(helpArea));

        JPanel resultCard = new JPanel(new BorderLayout(0, 7));
        resultCard.setBackground(PAGE);
        resultCard.add(sectionTitle("02  Kết quả và giải thích"), BorderLayout.NORTH);
        resultCard.add(tabs, BorderLayout.CENTER);
        workspace.add(resultCard, BorderLayout.CENTER);

        JPanel actions = new JPanel(new BorderLayout(8, 0));
        actions.setBackground(Color.WHITE);
        actions.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER),
                BorderFactory.createEmptyBorder(10, 20, 10, 20)));
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setBackground(Color.WHITE);
        styleButton(runButton, true);
        styleButton(cancelButton, false);
        styleButton(exportButton, false);
        buttons.add(runButton);
        cancelButton.setEnabled(false);
        buttons.add(cancelButton);
        exportButton.setEnabled(false);
        buttons.add(exportButton);
        autoExportBox.setBackground(Color.WHITE);
        autoExportBox.setForeground(MUTED);
        buttons.add(autoExportBox);
        actions.add(buttons, BorderLayout.WEST);
        progressBar.setIndeterminate(false);
        progressBar.setStringPainted(true);
        progressBar.setString("Sẵn sàng");
        progressBar.setForeground(TEAL);
        progressBar.setPreferredSize(new Dimension(130, 30));
        actions.add(progressBar, BorderLayout.CENTER);
        statusLabel.setForeground(MUTED);
        statusLabel.setBorder(BorderFactory.createEmptyBorder(0, 12, 0, 0));
        actions.add(statusLabel, BorderLayout.EAST);
        root.add(actions, BorderLayout.SOUTH);
    }

    private void wireActions() {
        runButton.addActionListener(event -> startRun());
        sampleButton.addActionListener(event -> useSample());
        pipaPresetButton.addActionListener(event -> {
            upperField.setText("0.02");
            lowerField.setText("0.01");
            statusLabel.setText("Đã đặt Su=0.02, Sl=0.01 cho PIPA");
        });
        cancelButton.addActionListener(event -> cancelRun());
        exportButton.addActionListener(event -> exportResult(true));
    }

    private void useSample() {
        inputField.setText(BUILT_IN_SAMPLE);
        formatBox.setSelectedItem("PIHAUPA");
        upperField.setText("0.23");
        lowerField.setText("0.10");
        statusLabel.setText("Đã chọn dữ liệu ví dụ - bấm Chạy PIHAUPA");
    }

    private void startRun() {
        if (worker != null && !worker.isDone()) {
            return;
        }
        RunOptions options;
        try {
            options = readOptions();
        } catch (RuntimeException ex) {
            showError(ex.getMessage());
            return;
        }

        setRunning(true);
        clearResults();
        cancelRequested = false;
        appendLog(options.inputPath == null ? "Đang dùng dữ liệu ví dụ tích hợp."
                : "Bắt đầu đọc " + options.inputPath.toAbsolutePath());
        worker = new SwingWorker<>() {
            @Override
            protected RunResult doInBackground() throws Exception {
                runningThread = Thread.currentThread();
                try {
                    checkCancelled();
                    publish("Đang đọc và chuẩn hóa dữ liệu...");
                    InputData input = loadInput(options);
                    checkCancelled();
                    publish("Đã đọc " + input.batches().stream().mapToInt(b -> b.transactions().size()).sum()
                            + " transaction; đang chạy PIHAUPA...");
                    AnalysisReport report = AnalysisReport.run(input);
                    checkCancelled();
                    return new RunResult(input, report, options.outputDirectory);
                } finally {
                    runningThread = null;
                }
            }

            @Override
            protected void process(List<String> chunks) {
                chunks.forEach(DesktopApp.this::appendLog);
                if (!chunks.isEmpty()) {
                    statusLabel.setText(chunks.get(chunks.size() - 1));
                }
            }

            @Override
            protected void done() {
                try {
                    RunResult result = get();
                    lastInput = result.input;
                    lastReport = result.report;
                    lastOutputDirectory = result.outputDirectory;
                    renderReport(result.report);
                    exportButton.setEnabled(true);
                    appendLog("Hoàn tất thuật toán.");
                    if (autoExportBox.isSelected()) {
                        exportResult(false);
                    }
                    statusLabel.setText("Hoàn tất");
                } catch (CancellationException ex) {
                    appendLog("Đã hủy tác vụ.");
                    statusLabel.setText("Đã hủy");
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    if (cause instanceof CancellationException || cause instanceof InterruptedException
                            || cancelRequested) {
                        appendLog("Đã hủy tác vụ.");
                        statusLabel.setText("Đã hủy");
                    } else {
                        appendLog("Lỗi: " + cause.getMessage());
                        showError(cause.getMessage());
                        statusLabel.setText("Có lỗi");
                    }
                } finally {
                    setRunning(false);
                }
            }

            private void checkCancelled() {
                if (cancelRequested || Thread.currentThread().isInterrupted()) {
                    throw new CancellationException();
                }
            }
        };
        worker.execute();
    }

    private InputData loadInput(RunOptions options) throws IOException {
        if (options.inputPath == null) {
            InputData builtIn = InputParser.parseBuiltInSample();
            return new InputData(options.upper, options.lower, builtIn.externalUtilities(), builtIn.batches());
        }
        boolean pipa = switch (options.format) {
            case "PIPA" -> true;
            case "PIHAUPA" -> false;
            default -> PipaDatasetParser.looksLikePipa(options.inputPath);
        };
        if (pipa) {
            return PipaDatasetParser.parse(options.inputPath, options.upper, options.lower,
                    options.splitRatios, options.maximumRows);
        }
        InputData parsed = InputParser.parse(options.inputPath);
        return new InputData(options.upper, options.lower, parsed.externalUtilities(), parsed.batches());
    }

    private RunOptions readOptions() {
        if (inputField.getText().isBlank()) {
            throw new IllegalArgumentException("Hãy chọn file dữ liệu.");
        }
        Path input = BUILT_IN_SAMPLE.equals(inputField.getText().trim())
                ? null : Path.of(inputField.getText().trim());
        double upper = Double.parseDouble(upperField.getText().trim());
        double lower = Double.parseDouble(lowerField.getText().trim());
        if (!(lower > 0.0 && lower < upper && upper <= 1.0)) {
            throw new IllegalArgumentException("Ngưỡng phải thỏa 0 < Sl < Su <= 1.");
        }
        long maximumRows = Long.parseLong(maximumRowsField.getText().trim());
        if (maximumRows < 0) {
            throw new IllegalArgumentException("Giới hạn dòng không được âm.");
        }
        Path output = outputField.getText().isBlank()
                ? Path.of(System.getProperty("user.home"), "Documents", "PIHAUPA Desktop")
                : Path.of(outputField.getText().trim());
        return new RunOptions(input, String.valueOf(formatBox.getSelectedItem()), upper, lower,
                PipaDatasetParser.parseSplit(splitField.getText().trim()), maximumRows, output);
    }

    private void cancelRun() {
        if (worker != null) {
            cancelRequested = true;
            Thread thread = runningThread;
            if (thread != null) {
                thread.interrupt();
            }
            cancelButton.setEnabled(false);
            statusLabel.setText("Đang hủy...");
        }
    }

    private void exportResult(boolean showDialog) {
        if (lastInput == null || lastReport == null || exporting) {
            return;
        }
        Path parent = outputField.getText().isBlank() ? lastOutputDirectory : Path.of(outputField.getText().trim());
        Path destination = parent.resolve("pihaupa-" + LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss-SSS")));
        InputData input = lastInput;
        AnalysisReport report = lastReport;
        exporting = true;
        exportButton.setEnabled(false);
        appendLog("Đang xuất kết quả vào " + destination.toAbsolutePath());
        new SwingWorker<Path, Void>() {
            @Override
            protected Path doInBackground() throws Exception {
                InputWriter.writeCombined(input, destination.resolve("pihaupa-input.txt"));
                if (input.batches().size() == 3) {
                    InputWriter.writeThreeSplitFiles(input, destination.resolve("splits"));
                }
                ReportWriter.writeAll(report, destination);
                return destination;
            }

            @Override
            protected void done() {
                exporting = false;
                exportButton.setEnabled(lastReport != null);
                try {
                    Path exported = get();
                    appendLog("Đã xuất kết quả: " + exported.toAbsolutePath());
                    if (showDialog) {
                        JOptionPane.showMessageDialog(DesktopApp.this, "Đã xuất vào:\n" + exported.toAbsolutePath(),
                                "PIHAUPA", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (Exception ex) {
                    Throwable cause = ex.getCause() == null ? ex : ex.getCause();
                    showError("Không thể xuất kết quả: " + cause.getMessage());
                }
            }
        }.execute();
    }

    private void renderReport(AnalysisReport report) {
        StringBuilder summary = new StringBuilder();
        summary.append("PIHAUPA - TỔNG QUAN\n");
        summary.append(String.format(Locale.US,
                "Ngưỡng: Su = %.4f (LARGE), Sl = %.4f (PRE-LARGE)%n", report.upperThreshold(),
                report.lowerThreshold()));
        summary.append(String.format(Locale.US,
                "Dữ liệu: %d batch, %d giao dịch%n", report.batchCount(), report.transactionCount()));
        summary.append(String.format(Locale.US,
                "Hiệu năng: %.3f ms; heap tăng %.3f MB; heap đỉnh quan sát %.3f MB%n",
                report.elapsedNanos() / 1_000_000.0,
                report.memoryDeltaBytes() / (1024.0 * 1024.0), report.peakMemoryBytes() / (1024.0 * 1024.0)));
        summary.append(String.format(Locale.US,
                "Tổng số lần quét lại: %d; mẫu đã duyệt: %d; node kết hợp: %d%n",
                report.stats().rescanCount(), report.stats().patternsVisited(), report.stats().combinedNodes()));

        performanceModel.setRowCount(0);
        for (AnalysisReport.BatchView batch : report.batches()) {
            performanceModel.addRow(new Object[]{batch.name(), batch.transactionCount(),
                    batch.cumulativeTransactionCount(), decimal(batch.elapsedMs()), decimal(batch.memoryAfterMb()),
                    decimal(batch.peakMemoryMb()), decimal(batch.batchTransactionUtility()),
                    decimal(batch.batchMaximumUtility()), batch.rescanTriggered() ? "Có" : "Không", batch.largePatterns().size(),
                    batch.preLargePatterns().size()});
            appendBatchExplanation(summary, report, batch);
        }
        AnalysisReport.BatchView finalBatch = report.batches().get(report.batches().size() - 1);
        if (finalBatch.largePatterns().isEmpty() && finalBatch.preLargePatterns().isEmpty()) {
            summary.append("\nKhông có mẫu đạt ngưỡng hiện tại. Có thể giảm Su/Sl và chạy lại. ")
                    .append("Với PIPA, thử nút “Ngưỡng gợi ý PIPA”.\n");
        }
        summaryArea.setText(summary.toString());
        summaryArea.setCaretPosition(0);

        patternModel.setRowCount(0);
        AnalysisReport.BatchView lastBatch = report.batches().get(report.batches().size() - 1);
        int displayed = 0;
        for (PatternResult pattern : concat(lastBatch.largePatterns(), lastBatch.preLargePatterns())) {
            if (displayed++ >= DISPLAY_PATTERN_LIMIT) {
                break;
            }
            patternModel.addRow(new Object[]{lastBatch.name(), pattern.type(), pattern.displayName(),
                    decimal(pattern.averageUtility()), decimal(pattern.sumUtility()), pattern.length()});
        }
        if (displayed > DISPLAY_PATTERN_LIMIT) {
            appendLog("Bảng pattern đã giới hạn " + DISPLAY_PATTERN_LIMIT + " dòng; CSV vẫn xuất đầy đủ.");
        }
    }

    private static void appendBatchExplanation(StringBuilder summary, AnalysisReport report,
                                               AnalysisReport.BatchView batch) {
        summary.append(String.format(Locale.US, "%n========== %s ==========%n", batch.name()));
        summary.append(String.format(Locale.US,
                "1. Dữ liệu: %d giao dịch mới; %d giao dịch tích lũy; TU(batch)=%.3f; MU(batch)=%.3f%n",
                batch.transactionCount(), batch.cumulativeTransactionCount(),
                batch.batchTransactionUtility(), batch.batchMaximumUtility()));
        summary.append(String.format(Locale.US,
                "2. Ngưỡng mẫu: TU(tổng)=%.3f; LARGE nếu AU >= %.3f; PRE-LARGE nếu %.3f <= AU < %.3f%n",
                batch.totalTransactionUtility(), batch.minUtilUpper(), batch.minUtilLower(), batch.minUtilUpper()));
        summary.append("3. Điều kiện quét lại:\n");
        if (batch.tightRescanLimit() == null) {
            summary.append("   DB0 là lần quét ban đầu; chưa áp dụng điều kiện re-scan.\n");
        } else {
            double oldTu = batch.totalTransactionUtility() - batch.accumulatedTransactionUtility();
            double left = batch.accumulatedMaximumUtility()
                    - report.upperThreshold() * batch.accumulatedTransactionUtility();
            double right = (report.upperThreshold() - report.lowerThreshold()) * oldTu;
            summary.append(String.format(Locale.US,
                    "   Từ lần quét toàn bộ gần nhất: TU(ID)=%.3f, MU(ID)=%.3f, TU(OD)=%.3f%n",
                    batch.accumulatedTransactionUtility(), batch.accumulatedMaximumUtility(), oldTu));
            summary.append(String.format(Locale.US,
                    "   PIHAUPA: MU(ID) - Su x TU(ID) >= (Su - Sl) x TU(OD)%n"
                            + "            %.6f %s %.6f -> %s%n",
                    left, left >= right ? ">=" : "<", right,
                    batch.rescanTriggered() ? "ĐẠT: quét lại" : "KHÔNG ĐẠT: chỉ cập nhật"));
            if (batch.tightRescanDenominator() <= 0.0) {
                summary.append("   Dạng chia Eq.(6): mẫu số <= 0; dùng phép so sánh hai vế ở trên.\n");
            } else {
                summary.append(String.format(Locale.US,
                        "   Dạng chia Eq.(6): MU(ID)=%.3f; giới hạn=%.3f%n",
                        batch.accumulatedMaximumUtility(), batch.tightRescanLimit()));
            }
            summary.append(String.format(Locale.US,
                    "   Điều kiện cũ (chỉ tham khảo): TU(ID)=%.3f; giới hạn=%.3f%n",
                    batch.accumulatedTransactionUtility(), batch.originalRescanLimit()));
        }
        summary.append(String.format(Locale.US,
                "4. Kết quả: %s; LARGE=%d, PRE-LARGE=%d; thời gian=%.3f ms%n",
                describeAction(batch.action()), batch.largePatterns().size(), batch.preLargePatterns().size(),
                batch.elapsedMs()));
    }

    private static List<PatternResult> concat(List<PatternResult> first, List<PatternResult> second) {
        java.util.ArrayList<PatternResult> result = new java.util.ArrayList<>(first.size() + second.size());
        result.addAll(first);
        result.addAll(second);
        return result;
    }

    private void chooseInput() {
        JFileChooser chooser = new JFileChooser();
        if (chooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            inputField.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void chooseOutput() {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        if (chooser.showSaveDialog(this) == JFileChooser.APPROVE_OPTION) {
            outputField.setText(chooser.getSelectedFile().getAbsolutePath());
        }
    }

    private void setRunning(boolean running) {
        runButton.setEnabled(!running);
        cancelButton.setEnabled(running);
        exportButton.setEnabled(!running && !exporting && lastReport != null);
        progressBar.setIndeterminate(running);
        progressBar.setString(running ? "Đang xử lý..." : "Sẵn sàng");
    }

    private void clearResults() {
        lastInput = null;
        lastReport = null;
        lastOutputDirectory = null;
        summaryArea.setText("");
        logArea.setText("");
        performanceModel.setRowCount(0);
        patternModel.setRowCount(0);
        exportButton.setEnabled(false);
    }

    private void appendLog(String message) {
        logArea.append(LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")) + "  " + message
                + System.lineSeparator());
        logArea.setCaretPosition(logArea.getDocument().getLength());
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(this, message == null ? "Lỗi không xác định" : message,
                "PIHAUPA - lỗi", JOptionPane.ERROR_MESSAGE);
    }

    private static JButton button(String label, Runnable action) {
        JButton button = new JButton(label);
        styleButton(button, false);
        button.addActionListener(event -> action.run());
        return button;
    }

    private static void styleButton(JButton button, boolean primary) {
        button.setUI(new BasicButtonUI());
        button.setFont(new Font("Segoe UI", Font.BOLD, 13));
        button.setForeground(primary ? Color.WHITE : NAVY);
        button.setBackground(primary ? TEAL : new Color(237, 243, 247));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(primary ? TEAL : BORDER),
                BorderFactory.createEmptyBorder(7, 13, 7, 13)));
        button.setFocusPainted(false);
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
    }

    private static void styleField(JTextField field) {
        Dimension size = field.getPreferredSize();
        field.setPreferredSize(new Dimension(Math.max(80, size.width), 32));
        field.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        field.setForeground(NAVY);
        field.setBackground(Color.WHITE);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER), BorderFactory.createEmptyBorder(3, 8, 3, 8)));
    }

    private static void styleTable(JTable table) {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setForeground(NAVY);
        table.setBackground(Color.WHITE);
        table.setSelectionBackground(new Color(221, 242, 240));
        table.setSelectionForeground(NAVY);
        table.setRowHeight(32);
        table.setShowVerticalLines(false);
        table.setGridColor(new Color(233, 238, 242));
        table.setIntercellSpacing(new Dimension(0, 1));
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setOpaque(true);
        headerRenderer.setFont(new Font("Segoe UI", Font.BOLD, 12));
        headerRenderer.setBackground(NAVY);
        headerRenderer.setForeground(Color.WHITE);
        headerRenderer.setBorder(BorderFactory.createEmptyBorder(0, 8, 0, 8));
        table.getTableHeader().setDefaultRenderer(headerRenderer);
        table.getTableHeader().setBackground(NAVY);
        table.getTableHeader().setPreferredSize(new Dimension(0, 36));
    }

    private static DefaultTableCellRenderer statusRenderer() {
        return new DefaultTableCellRenderer() {
            @Override
            public java.awt.Component getTableCellRendererComponent(JTable table, Object value,
                    boolean selected, boolean focused, int row, int column) {
                super.getTableCellRendererComponent(table, value, selected, focused, row, column);
                if (!selected) {
                    boolean active = "Có".equals(value) || value == PatternType.LARGE;
                    setForeground(active ? TEAL : MUTED);
                    setBackground(Color.WHITE);
                }
                setFont(new Font("Segoe UI", Font.BOLD, 13));
                return this;
            }
        };
    }

    private static JScrollPane scroll(java.awt.Component content) {
        JScrollPane pane = new JScrollPane(content);
        pane.setBorder(BorderFactory.createLineBorder(BORDER));
        pane.getViewport().setBackground(Color.WHITE);
        return pane;
    }

    private static JLabel sectionTitle(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 15));
        label.setForeground(NAVY);
        return label;
    }

    private static void addFormRow(JPanel form, GridBagConstraints c, int row, String label,
                                   java.awt.Component main, java.awt.Component trailing) {
        c.gridy = row;
        c.gridx = 0;
        c.weightx = 0;
        JLabel caption = new JLabel(label);
        caption.setFont(new Font("Segoe UI", Font.BOLD, 12));
        caption.setForeground(MUTED);
        form.add(caption, c);
        c.gridx = 1;
        c.weightx = 1;
        form.add(main, c);
        c.gridx = 2;
        c.weightx = 0;
        form.add(trailing, c);
    }

    private static DefaultTableModel readOnlyModel(String... columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }

    private static String decimal(double value) {
        return String.format(Locale.US, "%.3f", value);
    }

    private static String describeAction(String action) {
        return switch (action) {
            case "INITIAL SCAN + PATTERN EXPANSION" -> "Quét ban đầu và xây dựng cây mẫu";
            case "NO RE-SCAN: UPDATE EXISTING PATTERN TREE" -> "Không quét lại; chỉ cập nhật các mẫu đang giữ";
            case "TIGHT RE-SCAN + FULL PATTERN EXPANSION" -> "Điều kiện re-scan thỏa; quét lại toàn bộ dữ liệu";
            default -> action;
        };
    }

    private record RunOptions(Path inputPath, String format, double upper, double lower,
                              double[] splitRatios, long maximumRows, Path outputDirectory) {
    }

    private record RunResult(InputData input, AnalysisReport report, Path outputDirectory) {
    }
}
